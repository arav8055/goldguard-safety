import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
import {createRequire} from 'node:module';
import {resolve,dirname} from 'node:path';
import {existsSync} from 'node:fs';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {collectionWeightProblem,quoteFinalStatus,consumerProblems,parseImport} from '../lib/goldguard/model.ts';
import {completeConsumer} from './transaction-fixtures.mjs';
const source=readFileSync(new URL('../lib/goldguard/journey.ts',import.meta.url),'utf8').replace("'./model'",JSON.stringify(new URL('../lib/goldguard/model.ts',import.meta.url).href));
const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {completeWithExceptions}=await import('data:text/javascript;base64,'+Buffer.from(compiled).toString('base64'));
const remake=()=>{const j=completeConsumer('Remake my gold');Object.assign(j.data,{actualChain:'7.2',actualRing:'3',finalGross:'10',newGross:'10'});return j;};
test('audit mismatch blocks collection review and cannot be labelled MATCH',()=>{const j=remake();assert.match(collectionWeightProblem(j),/10\.200 g.*10\.000 g/);assert.ok(consumerProblems(j,7).some(x=>x.includes('Collection weight mismatch')));assert.equal(quoteFinalStatus(j,'Gross weight','10','10'),'NEEDS CLARIFICATION');});
test('free-text explanation alone cannot bypass collection reconciliation',()=>{const j=remake();j.data.reconcileNotes='Jeweller gave an explanation';assert.ok(consumerProblems(j,7).some(x=>x.includes('Collection weight mismatch')));assert.equal(quoteFinalStatus(j,'Gross weight','10','10'),'NEEDS CLARIFICATION');});
test('previously reviewed inconsistent records cannot complete normally',()=>{const j=remake();assert.ok(j.reviewed.includes(7));assert.ok(consumerProblems(j,10).some(x=>x.includes('Collection weight mismatch')));});
test('explicit completion exceptions preserve mismatch, reason and weights',()=>{const j=remake();j.reviewed=j.reviewed.filter(s=>s!==7);const result=completeWithExceptions(j,'Collection discrepancy remains unresolved');assert.equal(result.data.completionReason,'Collection discrepancy remains unresolved');assert.ok(JSON.parse(result.data.completionIssues).some(x=>x.stage===7&&x.message.includes('Collection weight mismatch')));assert.equal(result.data.actualChain,'7.2');assert.ok(!result.reviewed.includes(7));assert.equal(quoteFinalStatus(result,'Gross weight','10','10'),'NEEDS CLARIFICATION');assert.throws(()=>completeWithExceptions(j,' '));});
test('corrected weights allow review and MATCH again',()=>{const j=remake();j.data.actualChain='7';assert.equal(collectionWeightProblem(j),null);assert.deepEqual(consumerProblems(j,7),[]);assert.equal(quoteFinalStatus(j,'Gross weight','10','10'),'MATCH');});
test('decimal addition reconciles without binary floating point noise',()=>{const j=remake();Object.assign(j.data,{actualChain:'7.982',actualRing:'3.014',finalGross:'10.996'});assert.equal(collectionWeightProblem(j),null);j.data.finalGross='10.995999';assert.ok(collectionWeightProblem(j));});
test('optional piece weights leave existing single-article flows unchanged',()=>{for(const mode of ['Buy new gold','Exchange old gold','Remake my gold','Sell old gold','Hand over old gold']){const j=completeConsumer(mode);assert.equal(collectionWeightProblem(j),null);}const j=remake();j.data.actualRing='';j.data.actualChain='10';assert.equal(collectionWeightProblem(j),null);j.data.ringWeight='3';assert.match(collectionWeightProblem(j),/final ring weight/);});
test('invalid individual weights remain blocked',()=>{for(const value of ['-1','0','abc']){const j=remake();j.data.actualChain=value;assert.ok(collectionWeightProblem(j));assert.ok(consumerProblems(j,7).length);}});
test('evidence classification and description survive backup round trip unchanged',()=>{const j=remake();j.evidence[0].type='Before-weight photo';j.evidence[0].description='App screenshot only — not an original receipt';const copy=parseImport(JSON.stringify({version:1,jobs:[j],comparison:[]})).jobs[0];assert.deepEqual(copy.evidence,j.evidence);});
// Render the actual UI components, resolving the project's TypeScript and alias imports.
const require=createRequire(import.meta.url),cache=new Map();
function load(file){
 file=['', '.ts','.tsx'].map(ext=>file+ext).find(existsSync);
 if(cache.has(file))return cache.get(file).exports;
 const module={exports:{}};cache.set(file,module);
 const code=ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;
 new Function('require','module','exports',code)(name=>name.startsWith('@/')?load(resolve(name.slice(2))):name.startsWith('.')?load(resolve(dirname(file),name)):require(name),module,module.exports);
 return module.exports;
}
test('actual final review labels attached copies, never infers original documents',()=>{const {FinalReview}=load(resolve('components/goldguard-journey.tsx'));const j=remake();j.evidence[0].description='App screenshot only';const html=renderToStaticMarkup(React.createElement(FinalReview,{job:j,go:()=>{},complete:()=>{}}));assert.match(html,/Attached evidence copies/);assert.doesNotMatch(html,/<b>Original documents<\/b>/);});
test('actual report retains evidence classification and flags old reviewed mismatches',()=>{const {ConsumerReport}=load(resolve('components/goldguard-consumer.tsx'));const j=remake();j.evidence[0].type='Before-weight photo';j.evidence[0].description='App screenshot only';const html=renderToStaticMarkup(React.createElement(ConsumerReport,{job:j,exportJob:()=>{}}));assert.match(html,/Before-weight photo/);assert.match(html,/App screenshot only/);assert.match(html,/Collection weight mismatch/);assert.match(html,/Needs review — collection weights do not reconcile/);assert.match(html,/<h3>Gross weight<\/h3>.*?<b>NEEDS CLARIFICATION<\/b>/);assert.match(html,/Attachments do not establish possession of original documents/);});
test('collection warning explicitly displays the absolute difference in either direction',()=>{for(const total of ['10.000','10.400']){const j=remake();j.data.finalGross=total;assert.match(collectionWeightProblem(j),/Difference: 0\.200 g\./);assert.ok(consumerProblems(j,7).some(x=>x.includes('Difference: 0.200 g.')));}});
test('matching collection weights render no mismatch or difference warning',()=>{const {Reconciliation}=load(resolve('components/goldguard-consumer.tsx'));const j=remake();j.data.actualChain='7';assert.equal(collectionWeightProblem(j),null);const html=renderToStaticMarkup(React.createElement(Reconciliation,{job:j}));assert.doesNotMatch(html,/Collection weight mismatch|Difference: /);});
test('exception report preserves calculated difference and reason without a false MATCH',()=>{const {ConsumerReport}=load(resolve('components/goldguard-consumer.tsx'));const j=completeWithExceptions(remake(),'Synthetic QA: unresolved collection discrepancy');assert.ok(JSON.parse(j.data.completionIssues).some(x=>x.stage===7&&x.message.includes('Difference: 0.200 g.')));const html=renderToStaticMarkup(React.createElement(ConsumerReport,{job:j,exportJob:()=>{}}));assert.match(html,/Difference: 0\.200 g\./);assert.match(html,/Synthetic QA: unresolved collection discrepancy/);assert.match(html,/<h3>Gross weight<\/h3>.*?<b>NEEDS CLARIFICATION<\/b>/);assert.match(html,/Needs review — collection weights do not reconcile/);assert.match(html,/GoldGuard assumes no legal tolerance and makes no allegation/);});
