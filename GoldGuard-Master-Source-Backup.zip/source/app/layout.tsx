import type { Metadata } from "next";
import "./globals.css";
import "./journey.css";

export const metadata: Metadata = {
  title: "GoldGuard — Jewellery Safety",
  description: "An independent companion for recording gold jewellery weights, quotations, receipts and transactions.",
  robots: { index: false, follow: false },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
