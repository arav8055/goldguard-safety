import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
const checks=[['TypeScript',['node_modules/typescript/bin/tsc','--noEmit','--incremental','false']],['Automated regression',['--experimental-strip-types','--test','tests/model.test.mjs','tests/consumer.test.mjs','tests/journey.test.mjs']]];
let output=`GoldGuard final regression — ${new Date().toISOString()}\n\n`;
for(const [name,args] of checks){const r=spawnSync(process.execPath,args,{encoding:'utf8'});output+=`${name}: ${r.status===0?'PASS':'FAIL'}\n${r.stdout||''}${r.stderr||''}\n`;process.stdout.write(output.slice(output.lastIndexOf(`${name}:`)));if(r.status!==0){writeFileSync('docs/final-regression.txt',output);process.exit(r.status||1);}}
writeFileSync('docs/final-regression.txt',output);
