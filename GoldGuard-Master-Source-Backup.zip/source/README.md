# GoldGuard V1.2 — Jewellery Safety

A local-first jewellery job-work record application. React 19, TypeScript, Vinext/Vite, accessible Radix/Shadcn primitives, browser IndexedDB. No jewellery records are sent to a backend. The hosted application is private to its owner; local development does not require an account.

## Run locally

Install Node.js 22.13+ (or a supported newer LTS release) and pnpm 11.25.0. Extract the project, open a terminal in its directory, then:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open the localhost URL printed by the command (normally http://localhost:5173). Use the same browser and origin to resume records. The archive excludes the managed preview profile, so a local checkout automatically uses the portable development mode. Do not double-click an HTML file; start the development server.

```sh
pnpm exec tsc --noEmit --incremental false
node scripts/final-regression.mjs
pnpm build
```

Production hosting uses the Sites Worker build. `pnpm start` runs the built Cloudflare Worker locally. There is no database migration or secret required for GoldGuard's local records.

## Product workflow

Dashboard → job details → weight verification → purity verification → design/allocation → quotation → pre-handover → manufacturing → collection → manual HUID record → final bill → completion → printable report.

- Exact piece entries, tested fineness, formulas and separate verified weight.
- Chain and ring design planning with optional Sagittarius/Dhanusu preset.
- Six quotation lines: fixed, per gram, percentage, included or not applicable. Unspecified is never zero.
- Manual GST or an explicit user-confirmed taxable base and rate. No universal tax/wastage rules.
- Checklists, per-stage notes, status and evidence in every workflow stage.
- Gold allocation, actual leftover and final weight differences, without invented tolerances.
- Up to three independent jeweller comparison columns; no ranking.
- Audit history, duplicate/delete, JSON backup/restore and print/save as PDF.

## Calculation conventions

- Starting gross gold = sum of positive piece weights; a blank piece makes the total incomplete.
- Original job-work fine-gold equivalent = recorded batch grams × tested fineness / 1000. Consumer modes use each piece’s net precious-metal grams × its tested fineness / 1000. Karat is a label, not an assay.
- Planned gross jewellery = chain + ring; expected gross remaining = starting − planned. This is not a fine-gold mass balance.
- Actual difference = actual − agreed. Leftover difference = actual leftover − expected gross remaining.
- Percentage charge = explicitly entered rupee base × percentage / 100. Per-gram charge = explicitly entered grams × rate. Fixed charges are recorded directly.
- Calculated money uses decimal rational multiplication and half-up rounding to 2 decimals per line. Inputs remain in their original fields and audit. Weight results retain up to 6 decimals and fine gold up to 9; the interface uses at least 3 and 6 respectively.
- Additional payment = itemised charges + GST − discount. Customer-supplied gold is not automatically added as a new gold purchase charge.
- Invoice reconciliation = making + wastage + hallmark + other including stones + GST − discount; compare to the entered invoice amount and quotation.

## Files

- `app/page.tsx`: working surfaces, reusable field/card components, workflow and reports.
- `app/globals.css`: design tokens, desktop/mobile layout and A4 print styles.
- `app/layout.tsx`, `public/favicon.svg`: app metadata and icon.
- `lib/goldguard/model.ts`: types, validators, workflow gates and deterministic calculations.
- `lib/goldguard/fields.ts`: form definitions and human-readable labels.
- `lib/goldguard/storage.ts`: IndexedDB, ordered atomic saves, revision conflict detection and JSON export.
- `tests/model.test.mjs`: calculation, validation, rounding and import tests.
- `docs/GOLDGUARD-FINAL-QA.md`: V1.2 final audit; `docs/QA-AUDIT.md` retains the original 26-test release audit.
- `QA.md`: original verification results.
- Remaining components/configuration/scripts: framework starter, accessible primitives and build/hosting support.

## Records and privacy

Records and evidence stay in IndexedDB on the current browser/origin. There is no cloud backup, synchronisation, encryption-at-rest feature, shared account database or automatic BIS verification. Browser clearing and private browsing expiry can remove data. Export regularly. Backups include private evidence and audit entries; store them securely.

Saves are serial and atomic. A revision mismatch prevents an older tab overwriting newer browser records; export unsaved changes before reloading. Use one editing tab at a time. Save failures retain the in-memory state and expose a backup action. Imported jobs receive new IDs and never replace an existing record. Backup size is limited by available browser memory and storage; evidence is limited to 5 MB/file and 30 files/job. Supported evidence: JPG, PNG, WebP and PDF. Print reports list evidence metadata; the JSON backup includes bytes.

Checklists and HUID results are user acknowledgements, not independent verification. Audit history is local and editable in an exported file, so it is not a tamper-evident legal ledger. Consecutive edits to the same field within 15 seconds are coalesced, retaining the initial old value and latest new value. Editing a stage invalidates its review and later reviews. Draft navigation remains available when fields are incomplete; review/completion actions validate requirements.

Official HUID workflow source: https://www.bis.gov.in/bis-apps/?lang=en (checked 28 September 2026). The user must verify externally in BIS Care and record the result. No legal, taxation, purity, fraud or trust certification is provided.

## V1.2 additions

The existing app and original job-work path remain in place. Buy new gold, exchange, remake, sale and handover modes add per-piece net weight/purity, explicit transaction rates, preserved approved designs, old-gold valuation, quote/final comparisons and nine report variants.

Gold rates are MANUAL, dated Goodreturns Bangalore references for 24K/22K/18K. The release includes a clearly dated 29 September 2026 reference (14880/13640/11160 rupees per gram). It becomes stale on later dates. No automatic feed, scraper, scheduler or API is running. Open the source and save a new dated record to update it. Rates are local to each browser. A transaction snapshot changes only when first explicitly recorded; later reference updates and duplicate jobs retain it. Create a new transaction for a different reference snapshot.

A purity-specific rate already reflects purity: new jewellery value = net grams × agreed rate. An explicitly fine-gold (1000) valuation uses grams × fineness / 1000 × fine-gold rate. Goodreturns describes its 24K reference as 999; the fine-basis reference comparison therefore uses grams × fineness / 999 × that reference. Reference values are indicative, not jeweller prices or legal limits.

Consumer purchase balance = gold value + itemised charges + explicit GST − discount − exchange credit where applicable. Remaking does not automatically charge again for customer-owned gold. Negative settlement means credit to the customer. Wastage calculator amounts enter the quotation only through the explicit apply button. Custom charge/wastage bases require an explanation.

Approved designs retain their specification and design evidence. Changing the saved specification requires another approval before reviewing that stage. Reports include evidence metadata; backups include original files and approval copies. Local histories are not tamper-proof legal records.

See `docs/LEGAL-REFERENCES.md`, `docs/RELEASE-NOTES-V1.2.md`, `docs/final-regression.txt` and the synthetic sample report/contact sheet. No customer records or QA browser database are shipped in the application.
