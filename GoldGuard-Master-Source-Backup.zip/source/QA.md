# GoldGuard validation record

Date: 28 September 2026. This continues the existing GoldGuard project; no application replacement or user-data migration was performed.

## Automated regression

Run the existing 18-test suite with `node --experimental-strip-types --test tests/model.test.mjs`, plus TypeScript checking and the production build. The saved terminal results accompany the final delivery.

Coverage includes: 8 + 3 = 11; 7.982 + 3.014 = 10.996; 10.996 × 916 / 1000 = 10.072336; no assumed fineness from a karat label; missing/zero/negative weights; invalid fineness; explicit zero fineness; incomplete target weights; fixed/per-gram/percentage/included/unspecified charges; manual and calculated GST; incomplete charges and excessive discounts; invoice arithmetic; stage-review gates; JSON round trips and malformed imports; extreme values and Indian currency formatting; decimal half-up monetary rounding; a complete synthetic transaction through every stage including handover and HUID requirements.

## Browser checks completed during implementation

- New job, piece weights, purity validation and fine-gold formula.
- Review/checklist progression and saving an unfinished draft.
- Reloaded draft retained weights, fineness, stage and history.
- Chain/ring targets, allocation and Sagittarius design preset.
- Per-gram making charges and all quotation mode controls; explicit non-applicable lines.
- Manual GST calculation example: 10.996 × ₹500 + ₹164.94 = ₹5,662.94.
- Collection weights, agreed/actual table and neutral leftover-difference notice.
- Report includes customer/jeweller, gold, charges, invoice, checklists, notes, evidence and history.
- JSON export generated a real downloaded file. That file passed the import parser and was imported through the interface as a separate job.
- Evidence PNG attached through the file chooser and appeared in the evidence list.
- Duplicate job appeared separately; deleting only the synthetic copy required confirmation and removed it. No user records were deleted.
- Comparison calculated ₹1,133.00 for the entered example; the fourth jeweller was disabled.
- Mobile sidebar and navigation operated inside a 390 × 844 CSS viewport; horizontal comparison scrolling remained contained.
- Save-conflict errors preserve in-memory edits and expose a backup action.

## Print review

All six pages of the generated A4 QA report were visually inspected from rendered PNGs. Text, rupee symbols, weights, checklists, evidence metadata and audit entries were legible; no text collisions or clipped content were observed. No print-layout correction was necessary.

The QA PDF was rendered from the actual report DOM and print CSS using WeasyPrint. The browser Print / Save as PDF control was exercised. A native operating-system print dialog and physical printer were not tested. Pagination may vary slightly with browser/printer settings.

## Final scope and limits

GoldGuard is a local-browser record keeper. HUID verification stays manual via official BIS Care. Tax rates and tax bases are entered/confirmed by the user. One batch fineness is supported per job. Evidence is local, with 5 MB/file and 30 files/job; import has a 50 MB backup limit. Print reports list evidence rather than embedding its full file contents. JSON exports include evidence bytes. Browser storage is not cloud backup or a tamper-evident ledger.

Use one editing tab at a time. The stored revision prevents a stale tab from overwriting newer records. The hosted app and a local development server have separate browser storage origins; use export/import to move records deliberately.

## Final browser regression

Desktop and 390-pixel mobile layouts were visually rechecked after resuming the exact source. A new synthetic draft was saved with 7.982 g and 3.014 g, then the browser was reloaded. Its name, 10.996 g total and Draft status remained intact. No existing records were removed. The browser session was fresh; test records from an earlier browser session are not product seed data.

The final console check found no GoldGuard application error. The browser's own extension emitted metadata-delivery errors from a `chrome-extension://` URL; these were outside the application and did not affect the workflow. Full prior feature-specific checks and final automated stage/validation checks are described above. Native BIS service verification remains deliberately outside the app.
