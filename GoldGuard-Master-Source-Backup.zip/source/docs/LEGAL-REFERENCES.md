# GoldGuard V1.2 source review — 29 September 2026

This is a record of sources actually checked, not a legal opinion or compliance certification. Scope is the wording used by this app. Check current official rules for the particular transaction.

| Source | What was checked | Retrieval scope |
|---|---|---|
| BIS Care — https://www.bis.gov.in/bis-apps/?lang=en | Manual official app verification route | Official page read |
| BIS jewellers FAQ — https://www.bis.gov.in/hallmarking-jewellers/?lang=en | Invoice particulars; FAQ Q47 says HUID on invoice is voluntary, Q50 lists article description/net precious-metal weight/carat and fineness/hallmarking charge | Official page read |
| BIS consumer protection — https://www.bis.gov.in/hallmarking-overview/consumer-protection/?lang=en | Official consumer resource and testing route | Official indexed excerpt checked; direct page timed out |
| CBIC sectoral FAQ — https://cbic-gst.gov.in/hindi/sectoral-faq.html | Jewellery FAQ Q7 discusses total transaction value including making charges | Official search excerpt checked; app does not impose a universal GST mode/rate |
| National Consumer Helpline — https://consumerhelpline.gov.in/public/about | 1915, pre-litigation grievance support; no guaranteed remedy | Official page read |
| Department of Consumer Affairs Legal Metrology — https://consumeraffairs.gov.in/pages/legal-metrology-overview | Weight/measure standards in trade | Official indexed excerpt checked; direct retrieval timed out; no tolerance inferred |
| Consumer Protection Act 2019 — https://consumeraffairs.gov.in/public/upload/files/CP%20Act%202019_1732700731.pdf | Official statutory reference exists | Official indexed excerpt checked; full PDF retrieval timed out. No claim of full Act review |

## Other sources, not legal authorities

Goodreturns Bangalore: https://www.goodreturns.in/gold-rates/bangalore.html — page read via search on 29 September 2026. Published rates: 24K ₹14,880/g (99.9%); 22K ₹13,640/g (91.6%); 18K ₹11,160/g (75%). Page excludes GST/TCS/other levies. Initial app reference is dated and labelled manual. A direct runtime fetch returned HTTP 403, so no reliable automated feed was established. No permission or partnership is implied.

GIA CAD/CAM education: https://www.gia.edu/gem-education/program-jewelry-design-cad-cam — page read; CAD models/rendering/manufacturing education. “5D” is treated as a term to ask the jeweller to define, not a purity or legal standard.

## Claims deliberately avoided

No BIS/government affiliation; no automated HUID check; no verified-purity badge; no legal wastage/making cap; no legal weight tolerance; no guarantee of grievance success; no fraud verdict; no jeweller ranking; no government-mandated gold price. HUID test fixtures are synthetic and do not represent a real BIS verification.

## Store guide / app information separation — 29 September 2026

The store guide is now distinct from GoldGuard terms/privacy. Additional sources checked for this correction:
- BIS Consumers FAQ: https://www.bis.gov.in/hallmarking-overview/hallmarking-faqs/mandatory/?lang=en — official indexed answer permits consumers to sell existing hallmarked/unhallmarked jewellery; direct fetch failed. No obligation on a store to accept a particular price is inferred.
- BIS Jewellers FAQ re-read: invoice particulars and voluntary invoice HUID; scope/exemptions remain qualified.
- CBIC https://cbic-gst.gov.in/sectoral-faq.html — direct page read, reverse-charge FAQ 9 about an individual's personal old-jewellery sale outside business. Historical FAQ is guidance, not a blanket current tax exemption.
- CBIC https://cbic-gst.gov.in/faq.html — direct page read, exchange valuation FAQ 147; its own educational/no-legal-validity qualification retained in the guide.
- CBIC Hindi-path sectoral FAQ indexed Q7 — 3% jewellery transaction including making charges, subject to current classification/rules. No calculation default changed.
- NCH Consumer Protection Act overview: https://consumerhelpline.gov.in/public/knowledgebasedetails/Consumer%20Protection%20Act%202019 — direct page read, consumer rights. Selling one's own asset is not assumed to create buyer-side consumer status.
- NCH about page and Legal Metrology official indexed guidance rechecked for complaint and weighing routes.
- OpenAI privacy policy https://openai.com/policies/privacy-policy/ — current page read; linked only as a provider privacy reference, not as GoldGuard's own policy. Local storage does not imply the hosting/sign-in provider collects no technical data.

Practical store checklists are recommendations. Making/wastage/buyback terms are commercial agreements. No compensation formula, guaranteed refund, universal wastage cap, or automatic legal compliance is asserted.
