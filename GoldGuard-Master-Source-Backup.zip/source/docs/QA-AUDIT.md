> Historical original-workflow audit. For V1.2 results see GOLDGUARD-FINAL-QA.md.

# GoldGuard strict QA audit

Baseline: 28 September 2026, commit 5cc468b64d4aa5dd5bcf028fc6cef061c2b05603. Existing implementation audited before product edits. Synthetic records only; existing records preserved. Desktop Chrome and a 390 × 844 iframe viewport (375 px content width with scrollbar). Tests run against the existing managed preview. No live jewellery or tax determination was performed.

## Baseline workflow results

| # | Workflow | Baseline result / observed evidence |
|---|---|---|
|1|Create job|PASS — labelled synthetic job created|
|2–3|8 g + 3 g|PASS — 11.000 g|
|4|10.996 g|PASS — 7.982 + 3.014 retained; independent verified weight recorded|
|5–6|916 fineness / fine gold|PASS — 10.072336 g; 1001 rejected; no implicit karat conversion|
|7–8|Chain / ring|PASS — targets 8 and 2.5 g; planned 10.5 g; remaining 0.496 g|
|9|Making|PASS ordinary input — 500 × 10.996 = ₹5,498; FAIL fractional-rate formula text (F1)|
|10|Wastage|PASS — 2% of explicit ₹10,000 = ₹200; explanatory fields do not double-charge|
|11|Hallmarking|PASS — ₹90 fixed charge|
|12|GST|PASS ordinary input — manual ₹173.64 and 3% of ₹5,788 agree; FAIL sub-paise rounding (F1)|
|13|Total|PASS ordinary input — ₹5,911.64 after ₹50 discount; FAIL fractional lines (F1)|
|14–16|Save / refresh / resume|PASS — all saved fields and quotation restored after actual reload|
|17|Handover|PASS — checklist, receipt/evidence, dates and order recorded; changed order invalidates earlier review|
|18|Final weights|PASS — chain 7.99, ring 2.51; differences −0.010/+0.010 g; total difference zero|
|19|HUID|PASS — independent synthetic CHN123/RNG123; manual result recorded; no automatic-verification claim|
|20|Final bill|PASS normal ₹5,911.64 reconciliation; FAIL zero net metal weight accepted (F2)|
|21|Report|FAIL — repeated HUID/purity/design labels omit article identity (F3)|
|22|Three jewellers|PASS normal totals ₹1,300/₹1,400/₹1,500; fourth disabled; FAIL fractional rounding (F1)|
|23–25|Invalid / empty / negative|PASS basic bounds and review blocking; NEEDS IMPROVEMENT stale errors (N1); FAIL imported review structure (F4)|
|26|Mobile|PASS menu opens/closes and comparison scroll stays inside page; NEEDS IMPROVEMENT contrast (N2)|
|27|Desktop|PASS navigation and layout; NEEDS IMPROVEMENT contrast (N2)|
|28|Print/PDF|NEEDS IMPROVEMENT — 13-page synthetic report visually inspected; no clipped pages; ambiguous labels and split evidence note (F3)|
|29|Export/import|PASS actual JSON round trip with evidence and new IDs; FAIL self-backup count/size limits (F5); NEEDS IMPROVEMENT omitted comparison counts (N3)|
|30|Duplicate/delete|PASS — copied job resets review, confirmed deletion removes only test copy; originals remain|

## Confirmed defects and improvements

- **F1 FAIL, medium:** five invoice lines of 0.004 display ₹0.00 individually but sum to ₹0.02. Manual GST returns unrounded 0.004 despite the stated per-line rounding policy. Comparison has the same aggregate rounding. A 0.004/g rate × 100 g displays the false formula “100.000 g × ₹0.00/g = ₹0.40”. Reproduced with production model functions.
- **F2 FAIL, medium:** final-bill review accepts net precious metal weight 0 with all other fields/checks filled. Positive article weight is required.
- **F3 FAIL, medium:** report DOM and rendered page 3 contain two indistinguishable “HUID”, “Purity mark”, “Verification date”, and “Target gross weight” labels. Report also exposes camel-case tax labels. Evidence explanatory note splits from its short evidence list.
- **F4 FAIL, medium:** parser accepts fifteen copies of reviewed stage 0, allowing progress above 100%; permits stage 11 in reviewed list and array-shaped checks. Must reject malformed review metadata.
- **F5 FAIL, high:** application can create more than 100 pieces/500 jobs and attach enough files to exceed 50 MB, but its own backup parser rejects those exports. A 101-piece application-shaped fixture is rejected. Fixed caps are not shared by record creation and import.
- **F6 FAIL, medium (source review):** attachment reader appends to the job object captured before asynchronous FileReader completion. Another upload/removal while reading can be lost or resurrected. Requires current-state append, rather than replacing the captured evidence array.
- **N1 NEEDS IMPROVEMENT:** review-error list remains after correcting inputs (observed empty-name error after a name was entered). Clear stale results when fields change.
- **N2 NEEDS IMPROVEMENT:** secondary text is too faint: #7d847a on white, #80877e on #f7f8f5, and #7b8278 on white are below 4.5:1. Several select labels have htmlFor pointing to no actual trigger ID (source/DOM review). Native inputs and dialogs otherwise expose accessible names.
- **N3 NEEDS IMPROVEMENT:** import with a full comparison silently retains zero of three incoming cards after a generic capacity warning. Confirmation should state exact added/skipped counts and that skipped cards remain only in the selected backup.

## Security, terminology, and scope

PASS scoped checks: app records/evidence are browser-local IndexedDB; backup import validates supported data URLs and rejects active HTML evidence; React renders entered text as text; private Site remains owner-only. No application-origin error observed in browser logs during baseline; browser extension metadata errors were present and are not application exceptions. This is not a penetration test or full screen-reader certification.

BIS wording checked against official BIS Care and hallmark FAQs on 28 September 2026: https://www.bis.gov.in/bis-apps/?lang=en and https://www.bis.gov.in/hallmarking-overview/hallmarking-faqs/hallmarking-faq/?lang=en. HUID is six-character alphanumeric and verified manually through BIS Care; synthetic results here do not assert real verification. No tax rate, legal tolerance or certification is inferred by GoldGuard.

The existing 18 automated model tests passed before fixes. Date fields were exercised using native keyboard controls because the automation fill operation alone did not commit Chrome date segments reliably. Browser print-dialog output is not available through this automation; PDF inspection uses actual report DOM and CSS rendered with WeasyPrint, with that renderer limitation disclosed.

## Retest

Final verification completed 29 September 2026 against the patched application.

| Check | Final result |
|---|---|
| Automated model regression | PASS — 26 tests, zero failures (18 original + 8 targeted regressions) |
| TypeScript | PASS — no errors |
| F1 money rounding | PASS — per-line half-up money across quote, invoice and comparison; browser shows five 0.004 lines total ₹0.00; normal invoice remains ₹5,911.64 |
| F2 zero invoice net weight | PASS — browser review blocks 0; correction accepted |
| F3 report identity/print | PASS — separate Chain/Ring labels; 13 rendered A4 pages inspected through page images/contact sheet; evidence section stays intact; no clipping/overlap observed |
| F4 malformed reviews | PASS — duplicate stages, report-stage review and array-shaped checks rejected |
| F5 backup caps | PASS — 501-job/101-piece fixture and >50 MB valid-evidence fixture restore; actual browser backup import preserves evidence and comparisons |
| F6 asynchronous evidence | Fixed — append uses latest state and concurrent file reads are guarded; existing evidence survives import/reload. Deliberately slow concurrent-reader stress test not performed |
| N1 stale errors | PASS — browser error alert clears immediately after correcting an input |
| N2 readability/labels | PASS scoped visual/DOM check — secondary text darkened; select trigger IDs match labels; desktop and mobile layout inspected |
| N3 import disclosure | PASS — dialog states exact comparison cards added/skipped; existing cards preserved |
| Record persistence | PASS — imported records survive reload; edited/recompleted invoice survives a second reload with All changes saved |
| Report/export | PASS — report generated in browser; exported JSON contains 1 completed job, 1 evidence file, fineness 916 and bill ₹5,911.64 |
| Desktop/mobile | PASS — dashboard visually inspected at desktop and 390 px iframe width; mobile comparison totals ₹1,300/₹1,400/₹1,500; contained horizontal comparison scroll |
| Runtime | PASS scoped check — no application-origin errors; browser-extension metadata errors excluded |

No new application source changes were required in finalization. README's obsolete 50 MB import limitation was corrected. Test-only responsive harness is excluded from release.

### Remaining limitations

Records remain local to the browser/origin, without cloud sync or automatic backups. Export regularly. Maximum practical backup size depends on browser memory/storage. Printed evidence is metadata only; original files are in JSON backups. HUID verification remains manual through BIS Care. PDF visual QA used WeasyPrint with actual report DOM/CSS; native print-dialog pagination may vary. Mobile QA uses a narrow Chrome viewport, not physical iOS/Android devices. These scoped checks are not a full accessibility certification or penetration test.

