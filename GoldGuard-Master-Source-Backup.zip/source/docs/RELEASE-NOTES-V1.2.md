# GoldGuard V1.2 release notes

## Changed
- Added purchase/exchange/remake/sale/handover consumer workflows alongside the original workflow.
- Added dated manual Goodreturns Bangalore reference history, source/stale-state disclosures, immutable transaction snapshots and rate comparisons.
- Added per-piece net weight/fineness, explicit old-gold valuation, credit/settlement, wastage calculator and quote/final reconciliation.
- Added preserved design approval/evidence versions, richer evidence labels, consumer/legal/design information and nine selectable reports.
- Extended neutral three-jeweller comparison with rates, credit, delivery, warranty and missing-information fields.
- Corrected consumer discount handling, 999-reference fineness comparison, custom-basis validation, post-approval edits and mobile currency wrapping.
- Increased automated coverage from 26 to 69 passing tests. Improved print text size/page numbering.

## Preserved
Same Site, private owner-only audience, IndexedDB database and version-1 backup compatibility. No record deletion/migration/reset. Original chain/ring workflow, rational decimal calculations, editable drafts, evidence, history, conflict protection, duplication, deletion, backup import-as-copies and print/report remain. Original 26 tests are unchanged.

## Known boundaries
Manual rates only. Browser-local records; no cloud sync, encryption feature or automatic backup. Native printer pagination may differ from the inspected WeasyPrint rendering. Physical device, full screen-reader and penetration tests were not performed. See final QA and legal-source review for exact scope.

## Consumer-information correction
- Split “Buying & selling gold” (in-store consumer guidance and official references) from “GoldGuard terms & privacy” (app purpose, data handling, limitations and legal information).
- Added buying, personal sale, exchange/handover, charges/tax and complaint guidance, with source links beside the relevant statements.
- Added separate sidebar entries and links between the pages. Existing calculations, storage, workflows and report disclaimer are unchanged.
