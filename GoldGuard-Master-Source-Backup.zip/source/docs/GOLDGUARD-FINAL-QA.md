# GoldGuard V1.2 final QA

Date: 29 September 2026. Existing application continued from d8e4d016dbfb5cdcab15d4926d3a73901cad8322. All browser test entries are explicitly synthetic. No customer data was deleted or replaced.

## Release test result

PASS — 69 automated tests, 69 passed, 0 failed, 0 skipped; TypeScript passed. Original 26 tests remain unchanged, with 43 consumer/regression tests added. Every test name and result is in `final-regression.txt`. Production build/deployment results are recorded separately in the final handoff.

## Functional checks

| Area | Result and evidence |
|---|---|
| Original workflow | PASS — all 26 original model tests; existing completed chain/ring record retained after the upgrade and refresh |
| Weight/fine gold | PASS — 8 + 3 = 11.000; 7.982 + 3.014 = 10.996; 10.996 × 916 / 1000 = 10.072336. New browser form showed net/fineness result correctly |
| Purity, net/gross, invalid values | PASS — model tests cover missing/negative/zero/excessive/malformed values, purity limits and net exceeding gross |
| Purchase quotation | PASS — browser: 10 g × 13750 + making 5000 + GST 4275 − discount 100 = ₹146675; individual charge bases remain explicit |
| Other consumer modes | PASS — imported synthetic exchange/remake/sale/handover fixtures, validated all stages, completed each in browser; records persisted |
| Rates | PASS — reference source/date/method visible, manual blank validation, saved history after reload, snapshot remained 13640 after a synthetic daily reference change to 14000 |
| Rate maths | PASS — 24K/22K/18K/custom values; rate difference ₹160/g and 1.173%; accepted purity is not multiplied twice; 999 source-reference distinction tested |
| Design approvals | PASS — versions 1/2 retained; browser changed design to version 3, review blocked until new approval saved; evidence snapshots retained |
| Handover/evidence/HUID/bill | PASS scoped workflow validation and synthetic completion; PNG upload, imported evidence, external-manual-HUID fields and itemised final balance exercised. No real assay/HUID verification claimed |
| Three-jeweller comparison | PASS — mobile 3 cards, add limit disabled, third entered charges calculated ₹100, stacked cards without horizontal overflow; original comparison rounding covered |
| Backup/restore | PASS — actual browser export contained 6 jobs, 6 evidence files, 5 design approvals, 3 rate records, 1 comparison and 5 unchanged snapshots; importing that exact export produced 12 jobs and 12 files without overwriting originals; reload retained 12 jobs |
| Duplicate/delete | PASS from original audited UI and retained 26-test release; functions preserved. Not newly destructive-tested against user records |
| Reports | PASS — selected all 9 report variants in browser and verified headings; original completed report retained; JSON export verified |
| Persistence/conflicts | PASS — saved records, daily references, rate snapshots and evidence survived reload. Simultaneous preview tabs triggered the explicit conflict warning; single-tab reload restored All changes saved. No silent overwrite observed |

## Visual and runtime

PASS — desktop dashboard visually inspected (1348 px document viewport; page width identical). Mobile app inspected in Chrome iframe at 390 px outer width (375 content); each of 11 stage screens rendered and measured without horizontal overflow. Three comparison cards and mobile menu exercised; inputs entered successfully. Additional 320/768/1024 outer-width checks reported page width equal to viewport. Mobile rate digits initially wrapped; corrected to stacked no-wrap values and visually retested. This is viewport testing, not physical iOS/Android testing.

PASS — sample complete report generated from actual rendered report DOM and final application stylesheet, rendered with WeasyPrint into 10 A4 pages. All pages inspected via contact sheet, with detailed quotation/rate page inspection; no clipping/overlap observed; page numbers visible. Nine shorter report selections rendered in browser. Native Chrome print-dialog output was not captured; pagination may vary. Evidence files are metadata in print, bytes in JSON.

PASS scoped console check — no application-origin critical errors observed. Chrome-extension metadata messaging errors were excluded from application results. No production UI claim is made until the deployed page is tested.

## Security/accessibility scope

PASS scoped review — owner-only private access confirmed in Site access policy; no groups/external viewers. Application components have no record-upload/fetch/sendBeacon path. No hardcoded private keys/API-token patterns found in app/components/lib/public/docs/tests. Backups reject active HTML data URLs, malformed rate URLs/snapshots, prototype keys, invalid approval evidence and malformed stage metadata. React renders text values, and evidence views use validated JPG/PNG/WebP/PDF and noopener/noreferrer. Labels, semantic controls, focus styles, skip link and 44 px consumer navigation controls inspected.

NEEDS IMPROVEMENT / outside tested scope — no independent penetration test, dependency vulnerability audit or full screen-reader/WCAG certification. Local records/backups are not encrypted by this app, are not tamper-evident and can be lost if browser data is cleared. Browser quota and very large imports depend on available memory/storage. No cloud backup or cross-device sync.

## Issues found and resolved

- Consumer discount validation incorrectly considered only charges: corrected to include gold value in purchase total, regression added.
- Fine-basis reference comparison needed source 24K=999 adjustment: corrected and independently tested.
- Custom wastage missing explanation, malformed evidence-stage input and stale approved design review: validation fixed with targeted tests; design browser retest passed.
- Mobile currency digits wrapped: stacked no-wrap rate rows; retest passed.
- Snapshot instruction incorrectly suggested a duplicate could take another date: corrected; duplicates intentionally retain the snapshot.
- Print datum text increased to 9 pt, audit to 8 pt; page numbering added and final pages inspected.

One initial new test expected ₹149876.35 rather than the independently calculated half-up ₹149876.36; the incorrect test expectation was corrected. None of the original 26 tests was relaxed. An initial PDF extraction omitted application CSS; that QA artifact was discarded and regenerated with actual CSS.

## Sources and remaining limitations

See `LEGAL-REFERENCES.md` for exact source URLs, retrieval scope and dates. Goodreturns is manual only; direct runtime fetch returned 403. Some official pages/Consumer Protection Act PDF could only be checked via official indexed excerpts; full-PDF review is not claimed. GST base/rate remain explicit customer-confirmed inputs, not universal legal advice. No legal certification, real purity certification or automated BIS verification.

## Consumer information correction — verified 30 September 2026

Separated the original combined page into two independent navigation entries: Buying & selling gold (store-consumer guidance) and GoldGuard app info (application terms, privacy and limitations). Calculations, storage, record handling and the report disclaimer are unchanged.

PASS — desktop preview: both complete pages rendered; headings and cross-page buttons verified; no horizontal overflow at 1348 px. The Selling topic anchor placed the section heading approximately 24 px from the viewport top.

PASS — mobile preview: 390 px iframe / 375 px content; both pages measured width equal to viewport with no horizontal overflow. Menu navigation, both cross-page buttons and keyboard navigation exercised. Store buying/selling/exchange/tax/rights sections and separate app privacy/backup sections rendered. No application-origin console errors were returned in the inspected log. Screenshot capture of the final mobile state timed out after successful visual inspection; desktop proof images are retained. Physical-device testing was not performed.

The 69-test suite passed following the information-page split. The final release command reruns TypeScript and all 69 tests before building. The test-only mobile harness is removed from the release. Source review details are in LEGAL-REFERENCES.md. Deployment success is reported separately in the handoff; no claim of authenticated production-browser verification is made.
