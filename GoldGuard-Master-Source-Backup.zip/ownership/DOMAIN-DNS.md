# Domain and DNS — read-only platform snapshot, 2026-10-07

Domain: goldguardsafety.com. Registrar is GoDaddy according to the project/user context; registrar account ownership, actual DNS provider and authoritative nameservers were **not independently verified** in this archive task. No nameserver replacement was supplied by Sites. Do not infer that GoDaddy necessarily hosts DNS simply because it is the registrar.

Provider record: appgdom_6ac6569fb1e48191b6f97f96f85d0737; hostname goldguardsafety.com; provider status pending; registration status pending; SSL pending_validation. Current platform response had no last_error. Pending is not proof of a working custom-domain HTTPS deployment.

| Type | DNS host/name | Exact platform-supplied value |
|---|---|---|
| A | @ | 162.159.143.30 |
| A | @ | 172.66.3.26 |
| TXT | _openai-site-verification | openai-site-verification=mKWYGrPEcTmdipkPZRqNHYESLFQUl0ERDP2WJaEtECs |
| TXT | _cf-custom-hostname | 5aa03297-568d-489c-9f76-b3d5ae7cac20 |

Fully-qualified TXT names append .goldguardsafety.com. These are public DNS verification records, not authentication credentials. Preserve the exact strings; do not confuse them with private API tokens. A null record entry in the provider response supplied no usable additional value and is not a DNS record to create. Platform metadata also lists `custom-domains.chatgpt.site.` as its CNAME target, but the apex configuration supplied is the two A records above. Do not substitute a guessed apex CNAME. No TTL was specified by the platform; use the DNS provider's supported default when later authorized, unless platform guidance changes.

No www hostname registration was returned. www.goldguardsafety.com is not verified/configured by this task. If desired later, register that hostname separately and use its actual returned instructions. Do not assume www is redirected or covered by this certificate.

To finish/recover on Sites, an authorized owner must retain/add the hostname in the correct project, enter exact records at the authoritative DNS provider, then use the platform verification/status workflow until domain and SSL become active. Check HTTPS and certificate for the exact hostname afterward. Neither record changes nor status refresh/verification mutations were performed here. We did not verify actual public DNS contents or custom-domain HTTPS; only platform-required configuration was read.

If hosting changes, obtain new DNS values and verification challenges from the new host; recreate private access before switching traffic, retain mail/MX/TXT records and export old-origin GoldGuard data first. Registering a domain at a new host does not recover domain registrar access, renewals or ownership. Archive does not contain registrar credentials, nameserver administration access or SSL private keys. Current TXT challenges can become obsolete on re-registration and must be freshly obtained if the provider says so.
