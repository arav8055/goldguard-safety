# Release history and evidence

Snapshot commit `1665371bc3c035e046f0453806e316e9c2df8df5`, Sites saved version 8, 2026-10-07. This is a documentation archive, not a new GoldGuard release.

- Earlier user-confirmed milestones: 18, then 26 automated tests; editable local jobs, comparisons, evidence, export/import, refresh persistence, save-conflict protection, fineness/GST calculations and responsive fixes. These are historical reports, not independently re-performed in this archive task.
- Consumer expansion in source: five modes; flow version 2; versioned checklists; separate stone lines; manual rate history/snapshots; store guidance separated from app Trust Center; reports and preserved approvals. Existing source/docs contains historical QA/release notes, whose counts and labels may predate this snapshot.
- Confirmed release-critical fix: collection piece totals cannot pass normal consumer Collection/Completion review when inconsistent with finalGross. The report Gross weight row is forced to NEEDS CLARIFICATION. The recorded-exception path preserves the discrepancy/reason.
- Confirmed release-critical fix: the evidence indicator says **Attached evidence copies**. Classification and description remain in records, reports and backup; attachments do not prove possession of original documents.
- Confirmed release-critical fix: warning explicitly displays absolute **Difference: 0.200 g** for 10.200 g versus 10.000 g, preserving blocking/exception/no-false-MATCH behavior and neutral no-legal-tolerance language.
- Prior final verification recorded in task history: 116 automated tests passed, zero failed; TypeScript passed; production build passed; final interactive production smoke passed, including persistence, mismatch, exception and report behavior. These historical browser tests are not being claimed as a new full audit.
- This archive task: freshly installed dependencies from an isolated archive extraction, reran all automated tests, build and TypeScript; results are in REBUILD-AUDIT.md and verification/. No application edits, DNS changes, deployments or production data imports occurred.

Git messages are largely 'Update Site source' and do not establish feature-by-feature dates. Do not infer unsupported dates from them. No V1.1 changes have been made for archival purposes.
