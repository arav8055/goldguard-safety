# Runtime and dependencies

Observed archive environment: Node.js **24.19.0**, pnpm **11.25.0**, npm **11.9.0**. package.json requires Node >=22.13.0 and declares pnpm@11.25.0. Prefer the observed Node/pnpm versions for reproduction. TypeScript 5.9.3; JavaScript ES modules; tsconfig targets ES2022 with strict checking and bundler module resolution. React 19.2.6, Next API compatibility 16.3.4, Vinext 1.0.0-beta.5, Vite 8.0.13. This is a Vinext/Cloudflare build, not a conventional `next start` deployment.

## Exact commands, from source/

```sh
pnpm install --frozen-lockfile --prod=false
node --experimental-strip-types --test tests/*.test.mjs
pnpm run build
node node_modules/typescript/bin/tsc --noEmit --incremental false
pnpm run dev
# Or serve the built Worker locally (not a public production server):
pnpm run start
```

Build before TypeScript validation in a new checkout to generate route types referenced by next-env.d.ts. Development defaults to port 5173 in portable mode; start uses local Wrangler, defaults to its local port, and binds 127.0.0.1. There is no `test` package script. `scripts/final-regression.mjs` predates release-critical.test.mjs and explicitly runs only three test files; use the glob command above for all 116 tests. Do not run that historical script in the preserved repository because it writes docs/final-regression.txt.

pnpm-lock.yaml is the exact full transitive resolution/integrity manifest, and pnpm-workspace.yaml preserves build approval, minimum release age (10080 minutes), cache/store and sharp override policy. Dependencies are not vendored. Frozen installation needs the npm registry or a complete trusted package cache plus platform binaries. pnpm/native tooling is platform dependent. GNU timeout/flock/bash are used by managed install/build wrappers; portable mode defaults when .sites-runtime/execution-profile.json is absent. No .sites-runtime state is needed in the archive.

## Variables

No application API key, application environment variable or database secret is required by the active GoldGuard UI. .openai/hosting.json has project identity and null D1/R2 bindings, not credentials. The hosting service's custom-audience authentication configuration is external and must be recreated through the provider account. Credentials must be provisioned separately and must never be added to this archive.

Optional tool variables: CODEX_SANDBOX; SITES_RUNTIME_ROOT; SITES_PROJECT_ROOT; SITES_ENV_READY; SITES_INSTALL_REPORT_PATH; SITES_BUILD_TIMEOUT; SITES_BUILD_KILL_AFTER; CLOUDFLARE_CF_FETCH_ENABLED; WRANGLER_SEND_METRICS; WRANGLER_WRITE_LOGS; WRANGLER_LOG_PATH; WRANGLER_REGISTRY_PATH; MINIFLARE_REGISTRY_PATH. Scripts also have optional install/cache controls listed in ENVIRONMENT-VARIABLE-REFERENCES.txt. These are tooling controls, not required GoldGuard business inputs. Defaults suppress Wrangler telemetry and external cf metadata fetch. Replacement Cloudflare deployment requires its own account authentication (interactive wrangler login or securely supplied account/token), not a value from the source snapshot. Archive .env.example contains commented placeholders only; it is documentation and is not loaded automatically into source/.

## Declared and installed direct packages

The declared spec and currently installed resolution are listed below; pnpm-lock.yaml remains authoritative for transitives.

| Class | Package | Declared | Installed |
|---|---|---|---|
| dependencies | @base-ui/react | ^1.7.0 | 1.7.0 |
| dependencies | @hookform/resolvers | ^5.7.1 | 5.7.1 |
| dependencies | @shadcn/react | ^0.3.0 | 0.3.0 |
| dependencies | class-variance-authority | 0.7.1 | 0.7.1 |
| dependencies | clsx | 2.1.1 | 2.1.1 |
| dependencies | cmdk | ^1.1.1 | 1.1.1 |
| dependencies | date-fns | ^4.4.0 | 4.4.0 |
| dependencies | drizzle-orm | 0.45.2 | 0.45.2 |
| dependencies | embla-carousel-react | ^8.6.0 | 8.6.0 |
| dependencies | input-otp | ^1.4.2 | 1.4.2 |
| dependencies | lucide-react | ^1.31.0 | 1.31.0 |
| dependencies | next | 16.3.4 | 16.3.4 |
| dependencies | next-themes | ^0.4.6 | 0.4.6 |
| dependencies | radix-ui | ^1.6.7 | 1.6.7 |
| dependencies | react | 19.2.6 | 19.2.6 |
| dependencies | react-day-picker | ^10.0.1 | 10.0.1 |
| dependencies | react-dom | 19.2.6 | 19.2.6 |
| dependencies | react-hook-form | ^7.85.0 | 7.85.0 |
| dependencies | react-resizable-panels | ^4.12.2 | 4.12.2 |
| dependencies | recharts | ^3.8.0 | 3.8.0 |
| dependencies | sonner | ^2.0.8 | 2.0.8 |
| dependencies | tailwind-merge | 3.6.0 | 3.6.0 |
| dependencies | vaul | ^1.1.2 | 1.1.2 |
| dependencies | zod | ^3.25.76 | 3.25.76 |
| devDependencies | @cloudflare/vite-plugin | 1.37.1 | 1.37.1 |
| devDependencies | @cloudflare/workers-types | 4.20260515.1 | 4.20260515.1 |
| devDependencies | @tailwindcss/postcss | 4.2.1 | 4.2.1 |
| devDependencies | @types/node | 22.19.19 | 22.19.19 |
| devDependencies | @types/react | 19.2.14 | 19.2.14 |
| devDependencies | @types/react-dom | 19.2.3 | 19.2.3 |
| devDependencies | @vitejs/plugin-react | 6.0.2 | 6.0.2 |
| devDependencies | @vitejs/plugin-rsc | 0.5.26 | 0.5.26 |
| devDependencies | drizzle-kit | 0.31.10 | 0.31.10 |
| devDependencies | eslint | 9.39.4 | 9.39.4 |
| devDependencies | eslint-config-next | 16.3.4 | 16.3.4 |
| devDependencies | react-server-dom-webpack | 19.2.6 | 19.2.6 |
| devDependencies | tailwindcss | 4.2.1 | 4.2.1 |
| devDependencies | tw-animate-css | ^1.4.0 | 1.4.0 |
| devDependencies | typescript | 5.9.3 | 5.9.3 |
| devDependencies | vinext | 1.0.0-beta.5 | 1.0.0-beta.5 |
| devDependencies | vite | 8.0.13 | 8.0.13 |
| devDependencies | wrangler | 4.92.0 | 4.92.0 |
