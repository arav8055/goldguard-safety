# Tests and verification scope

Canonical command: `node --experimental-strip-types --test tests/*.test.mjs` from source. Four test files plus transaction-fixtures.mjs are included. Node's built-in test runner is used; TypeScript is stripped directly or transpiled by test helpers for rendered React components. There is no separate Jest/Playwright config to recover. Fixtures are synthetic technical data, not production customer records.

Historical verified state supplied in the project history: **116 passed, 0 failed; TypeScript passed; production build passed; final interactive production smoke passed**. Fresh isolated archive verification is recorded separately in REBUILD-AUDIT.md and verification/tests-audit.tap.

Test families: model arithmetic, money/weight rounding, validation and import contracts; consumer mode, rates/valuation and report behavior; journey/exception/checklist summaries; release-critical collection discrepancy, review block, exception persistence, evidence wording/classification, rendered report and backup behavior. The test file source is the exact scope. These tests do not constitute a full browser-device matrix, full PDF pagination validation, a provider deployment test, a penetration test or a fresh legal audit. Prior mobile/interactive results are historical, not rerun by the archive task. `scripts/final-regression.mjs` is historical and omits the release-critical file; do not use its older output as the final test count.

## Test declarations in preserved source


### consumer.test.mjs

- reference history loads all three quoted purities
- manual reference validates required inputs
- reference rejects impossible and future dates
- reference source rejects javascript and unrelated URLs
- reference does not pretend an automatic method exists
- missing and stale reference states are explicit
- latest reference selection does not mutate history order
- historical transaction snapshot survives daily rate changes
- 24K gold calculation
- 22K gold calculation
- 18K gold calculation
- custom gold rate calculation
- missing, negative, zero and excessive values stay incomplete
- rate difference uses reference denominator
- piece fine gold uses net weight excluding stones
- piece purity boundaries reject unsupported values
- accepted purity rate is not multiplied by fineness twice
- fine gold valuation uses explicit fine rate basis
- fine basis refuses mismatched reference purity
- exchange deductions and adjustments are visible in credit
- new purchase includes gold value plus charges tax discount
- exchange subtracts credit without changing tax base
- sell mode reports credit receivable
- remaking does not charge for customer-owned gold
- percentage wastage shows grams and value
- grams and fixed wastage modes
- custom charge requires calculation explanation
- final bill rounds individual lines then subtracts credit
- handover review blocks missing records and evidence
- net greater than gross cannot be reviewed
- HUID format is insufficient without official result
- old version-1 backups remain accepted without rates
- new backup round trip preserves rate snapshots and history
- backup rejects malformed reference and snapshot
- approved version is a deep copy of design and evidence
- backup rejects active content inside approved design evidence
- malicious filenames remain plain data in backup
- full new-purchase workflow validation accepts recorded data
- purchase discount may exceed charges when covered by gold value
- custom wastage requires an explanation
- malformed evidence stage is rejected before rendering
- fine reference comparison accounts for source 24K at 999 fineness
- changed approved design requires a new approval without losing the old version
- new sale/exchange records never assume unknown deductions or adjustment are zero
- separate stone invoice requires explicit values and never double counts other charges
- legacy invoice preserves combined stones and other total
- new payment review requires method and receipt reference
- resolved transaction checklist allows completion without rewriting earlier reviews
- new terms, question answers, invoice fields and evidence round trip unchanged
- all twenty reasons have distinct practical actions

### journey.test.mjs

- completion with exceptions rejects an impossible recorded date
- record ID is stored and survives backup round trip
- legacy record ID is deterministic without mutating record
- sale journey excludes manufacturing and preserves valuation/payment
- existing consumer records keep every detailed stage
- buyer does not need a custom design approval unless selected
- missing sale fields suggest neutral valuation questions
- answered rate details remove corresponding suggestion without mutating answers
- completion with exceptions retains unchecked items and missing-value report
- completion with exceptions requires a reason
- completion never bypasses invalid weights or fineness
- completion blocks net greater than gross
- fine total combines per-item results without treating gross as net
- archived records restore through compatible backup schema
- review progress counts only applicable stages and does not certify exceptions
- corrupted and partial stored payloads fail schema validation

### model.test.mjs

- 8 g + 3 g = 11 g
- measured decimal weights are retained
- fine gold uses tested fineness and preserves six decimals
- karat is not silently converted to fineness
- missing, zero and negative piece weights stay incomplete
- invalid purity is rejected
- zero fineness remains explicit zero, not missing
- missing target weight does not become zero
- each charge mode requires the appropriate input
- GST is calculated only on the entered base; manual mode preserved
- unspecified charges and excessive discounts cannot show a payable total
- invoice reconciliation respects entered figures
- incomplete stages cannot be reviewed
- JSON round trip retains all records without mutation
- import rejects invalid versions, broken jobs and active evidence
- extreme values never yield NaN or Infinity
- monetary ties round half-up without floating-point drift
- every stage accepts a fully recorded synthetic transaction
- all monetary totals round each line half-up before summing
- full discount has no binary-float false rejection
- fractional-rate formula retains the entered operand
- zero invoice net weight cannot be reviewed
- unused charge inputs do not block an included line
- import rejects duplicate reviews, report review and array-shaped checks
- self-generated backup accepts more than old job and piece caps
- valid evidence backup beyond former 50 MB limit restores

### release-critical.test.mjs

- audit mismatch blocks collection review and cannot be labelled MATCH
- free-text explanation alone cannot bypass collection reconciliation
- previously reviewed inconsistent records cannot complete normally
- explicit completion exceptions preserve mismatch, reason and weights
- corrected weights allow review and MATCH again
- decimal addition reconciles without binary floating point noise
- optional piece weights leave existing single-article flows unchanged
- invalid individual weights remain blocked
- evidence classification and description survive backup round trip unchanged
- actual final review labels attached copies, never infers original documents
- actual report retains evidence classification and flags old reviewed mismatches
- collection warning explicitly displays the absolute difference in either direction
- matching collection weights render no mismatch or difference warning
- exception report preserves calculated difference and reason without a false MATCH
