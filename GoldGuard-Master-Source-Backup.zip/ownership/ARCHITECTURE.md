# Architecture

## Structure and flow

```text
Customer browser -> React page and workflow components -> model/journey functions
                             |                                  |
                             +-> IndexedDB workspace <----------+
                             +-> JSON download / validated merge import
                             +-> HTML report -> browser print / PDF
Private Sites edge -> Cloudflare Worker (Vinext RSC/SSR) + built client assets
```

There is one active application page at `/` (app/page.tsx). Dashboard, records, five transaction journeys, comparison, reports, rates, store consumer information, app Trust Center and settings are client state views, not independent URL routes. Root layout supplies title, CSS, English language and noindex/nofollow metadata. Examples/d1 contains an inactive example API route, not an active GoldGuard endpoint.

app/page.tsx owns Store, active job, workflow stage, confirmation dialogs and field updates. Components/goldguard-consumer.tsx renders consumer stages; goldguard-journey.tsx renders the grouped customer journey; goldguard-transaction-record.tsx renders consumer reports and record summaries; goldguard-rates.tsx handles manual dated rates; goldguard-information.tsx separates store guidance from application information. goldguard-ui.tsx centralizes field/card/notice rendering. components/ui and hooks contain the reusable UI infrastructure. Legacy jobs remain supported through page.tsx and field/model definitions.

lib/goldguard/model.ts owns types, numeric parsing, BigInt decimal rounding, charge/quote/bill functions, mode-specific requirements, collection reconciliation, reference rates, JSON validation and transaction checklist definitions. fields.ts and consumer-fields.ts describe labels and inputs. journey.ts adds grouped stage navigation, report summaries, outstanding questions and completion-with-exceptions. No generic relational transaction backend is used.

## State, persistence and data flow

On mount, readRecords opens IndexedDB `goldguard-records-v1`, version 1, object store `records`, key `workspace`. A Store plus internal revision is saved. Records are scoped to browser profile and origin; they are not per-hosting-login server records. The read path validates stored records and refuses to overwrite invalid content. React updates are auto-saved after load; the UI reports save errors. saveRecords serializes structured-cloned snapshots, and a read/write transaction compares expectedRevision with stored revision to reject stale tabs. This is conflict detection, not cloud sync or a multi-user database.

Edits update timestamps, append/coalesce audit entries and invalidate applicable reviewed stages. A completed record edited through the ordinary update path returns to Preparing. Checklist ticks, notes and reviewed-stage arrays are separate. Audit history is locally editable data, not tamper-proof evidence. Approval snapshots preserve design data/evidence versions. Deletion, duplication and import operate on the browser workspace; no server records are deleted or duplicated.

## Backup and evidence

storage.download serializes the Store to formatted JSON. All-record export includes jobs, comparison cards and reference-rate history. Jobs include evidence base64 data URIs, metadata, audit, notes, exceptions and design approvals. Import parses/validates first, asks confirmation, generates new job IDs and display record IDs, retains the old record ID as importedRecordId and adds '(imported)' to names. It adds rather than overwrites jobs. Reference-rate IDs are regenerated. Comparison cards fill remaining slots to a maximum of three; skipped cards remain in the original backup. The IndexedDB conflict revision is not part of the exported Store schema. Sidebar/view state and platform access lists are not backed up by JSON.

Evidence upload uses FileReader, accepts JPEG/PNG/WebP/PDF up to 5 MiB and a UI limit of 30 files per job. It stores the user's classification and description with the bytes. Preview decodes to a Blob and opens an object URL with noopener. Import checks allowed MIME/data-URI format and an encoded size limit; it does not perform malware or content authenticity analysis. Reports list evidence metadata rather than embedding every attachment. Attached evidence copies are not proof of original document possession.

## Reports and printing

Consumer report components select complete/transaction/verification/money views and derive summaries using the same model functions. Legacy Report is in app/page.tsx. window.print invokes browser printing; app/globals.css and app/journey.css contain print rules. There is no dedicated PDF engine dependency. Save-as-PDF is a browser capability. A report PDF is generated output, not the authoritative stored record. Generation date changes when rerendered. Current record data plus source reconstruct report content, but pagination/fonts can vary by browser/OS.

## Hosting and external boundaries

Vite + Vinext + @cloudflare/vite-plugin produce dist/client and dist/server. build/sites-vite-plugin.ts and scripts retain Sites integration and portable local development support. The Worker serves React server output/assets, but business records remain in browser IndexedDB. db/ is unused scaffolding; .openai/hosting.json has no D1/R2 binding. app/chatgpt-auth.ts is an available edge-header helper and is not imported by the active root layout/page. Private access currently depends on Sites edge authentication, not that helper enforcing access in the page. Mock authentication is development-only; never treat it as a replacement access gate.

Production URL and project/version IDs are documented in DEPLOYMENT.md. Custom domain metadata is in DOMAIN-DNS.md. Changing domain creates another origin; records must be exported from the old origin and imported into the new one. Domain ownership, SSL, hosting access lists and registry packages are external dependencies.
