# GoldGuard ownership and recovery archive
Snapshot: 2026-10-07 UTC. Source commit `1665371bc3c035e046f0453806e316e9c2df8df5`. Sites release v8.

`source/` preserves the current application files without application edits. `ownership/` contains newly written archive documentation and verification evidence. Application data is deliberately separate in **GoldGuard-Data-Backup.zip**. Start with DISASTER-RECOVERY.md and REBUILD-AUDIT.md.

This archive preserves source and rebuild instructions, not ownership of third-party libraries, hosting infrastructure, registered domain accounts or authentication credentials. Existing dependency licences still apply. No new licence for the application is invented. The upstream Git remote/history is not required for reconstruction and is not embedded; the current commit and byte manifests identify this snapshot.

Older documents under source/docs, README.md and QA.md are preserved historical evidence, not current test-count or release instructions. The ownership documents and current test log distinguish fresh results from previously reported verification. No legal-source freshness audit or penetration test was performed for this archival task.

All generated screenshots/PDF previews under source/docs were excluded and listed by name/hash in EXCLUDED-FILES.json: they are historical generated QA outputs, not required source, and may contain record examples. Report templates, CSS and test fixtures are included. `public/transaction-illustrations.png` and all other runtime assets are included. No separately hosted runtime fonts or image dependencies were found; icons are source assets or package dependencies and typography uses CSS font stacks.

The package is rebuildable with externally obtained dependencies; it is not a fully offline, service-independent executable image. Private-access controls must be recreated before any replacement deployment is exposed. Do not deploy or alter DNS merely to verify this archive.
