# Third-party service and dependency register

| Service/library | Purpose | Dev / production need | Account/config/data | Replacement and severity |
|---|---|---|---|---|
| OpenAI ChatGPT Sites | Current source/version hosting, deployment, private audience and sign-in edge | Current workflow / current hosted site | Owner account/project/access list; source and built assets, provider technical/account data; GoldGuard records not uploaded by business UI | Replace host/access layer; high operational dependency |
| Cloudflare Workers/Vinext runtime | Worker SSR/RSC and client asset serving | Build/local emulator / current production architecture | Current Sites-managed worker; replacement account and access policy needed | Compatible Worker host easiest; other adapters unverified; high |
| Cloudflare custom hostname/SSL via Sites | Domain verification and TLS | No / custom domain | Public domain verification challenges; cert managed externally | Replacement host TLS service; high for custom URL |
| GoDaddy (user-reported registrar) | Domain ownership/renewal | No / only custom domain | Owner account required; account not exported; authoritative DNS provider unverified | Transfer registrar using authorized process; high for domain |
| Authoritative DNS provider | DNS records/nameservers | No / domain routing | Provider/account not established from platform metadata | Any supported DNS provider; high for domain |
| npm registry / pnpm | Download locked dependencies | Yes / build-time only | No project API key required for public packages; package metadata/download requests | Trusted complete mirror/cache; high rebuild dependency |
| React, Next compatibility, Vinext, Vite | App rendering and build | Yes / bundled runtime | Versions/lockfile supplied | Requires engineering to replace; high |
| Tailwind, shadcn/base-ui/radix, lucide and other UI libraries | Styling, controls, icons | Build / bundled as used | No external service account; licences apply | Replaceable source/UI dependencies; medium |
| Node.js, TypeScript, pnpm, Wrangler/workerd | Toolchain/emulation | Yes / Worker runtime compatibility | Native binaries may be platform-specific | Compatible pinned toolchain; high rebuild dependency |
| Browser IndexedDB | All local records/evidence | Browser / browser | Per-profile/origin data; no service account or cloud database | Supported JSON export/import; high data dependency |
| Browser print/Save as PDF | Report/PDF output | No / optional customer reporting | Browser/OS fonts and print settings; no PDF API account | Another compatible browser; medium output dependency |
| Goodreturns Bangalore | Indicative manual gold rate reference | No / optional reference link only | No automatic fetch, feed, key or account; user manually enters dated rates | Actual jeweller rate usable independently; source restriction in current manual reference validator; low core dependency |
| BIS / BIS Care | External manual hallmark/HUID information/verification | No / external user verification where applicable | Separate official app/service; GoldGuard stores user-entered result | Cannot replace BIS official verification with this archive; low app availability, important external verification |
| CBIC, Consumer Affairs, National Consumer Helpline, GIA | Linked consumer/legal/education information | No / optional external reading | No GoldGuard integration/API or credentials | Links/source content may change; low runtime dependency |

All direct libraries, including unused starter dependencies such as Drizzle, are enumerated in DEPENDENCIES.md; all transitives/integrities are in pnpm-lock.yaml. Third-party licences are not superseded by this archive. Vendor licences are included. No paid rate API, cloud evidence store, mail/SMS integration, dedicated PDF API or active GoldGuard D1/R2 database was found. Existing linked legal material is preserved, not freshly legally verified. Third-party pages are not an offline legal library.
