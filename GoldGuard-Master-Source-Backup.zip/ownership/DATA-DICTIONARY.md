# Data dictionary

All transaction data is stored inside the version-1 Store in IndexedDB records/workspace and included in supported JSON export unless stated otherwise. Business form numbers are **strings**, not numeric database columns. Optional blank drafts are allowed; stage review and calculation requirements are conditional. Import schema validation is distinct from business validation: it generally retains string values for later review. The exact validators in model.ts/journey.ts remain authoritative.

## Top-level and structured records

| Path/field | Type, purpose and requiredness | Validation / usage |
|---|---|---|
| Store.version | required literal 1 | import format version |
| Store.jobs | required Job[] | all records, including archived |
| Store.comparison | required string-map array, max3 | comparison cards; exported; import fills free slots |
| Store.rates | optional ReferenceRate[] | manual reference history; validated; exported |
| persisted revision | internal number, outside Store | stale-tab write guard; not a user report/export field |
| Job.id / name | required strings | id is internal UUID; name entered/displayed; import changes both id and name suffix |
| Job.created / updated | required date-parseable strings | timestamps; displayed/audit; exported |
| Job.stage | integer0..11 | current stage, exported; routing depends on flow version |
| Job.status | supported status string | Draft/Preparing/Handed Over/In Production/Ready for Collection/Completed/In progress/Archived |
| Job.data | required string map | all fields below; excludes prototype/constructor keys in import; values <20000 chars |
| Job.pieces | required nonempty Piece[] | individual articles, UI/report/calculations/export |
| Piece.id,description,weight | required strings | weight gross g; positive <=1e6 required by review/calculation; import checks string shape |
| Piece.net | optional string | net metal g; >0..1e6, <=gross at review/exception validation; fine calculation |
| Piece.components | optional string | non-gold component description/record; UI/report/export |
| Piece.fineness | optional string | 0..1000, required for pieceFine; UI/report/export |
| Piece.huid,test | optional strings | per-article HUID/test notes; no automatic verification |
| Job.charges | required exactly6 Charge[] | name/mode/value/base/notes strings; six labelled quote lines |
| Charge.name | string | Making/labour,Wastage,Hallmarking,Stones,Other1,Other2 defaults |
| Charge.mode | enum | Not specified,Fixed amount,Per gram,Percentage,Custom basis,Included,Not applicable |
| Charge.value/base/notes | strings | value and explicit base numeric where needed; custom notes required; printed formula and export |
| Job.checks | required boolean map | consumer-stage-index, transaction-index and legacy stage-index; UI/report/export |
| Job.reviewed | required unique integer[] 0..10 | reviewed stages; edits invalidate; report uses mismatch guard |
| Job.notes | required string map | stage notes, reported/exported; <20000 chars/import |
| Job.evidence | required Evidence[] | local file copies; export embeds bytes |
| Evidence.id/name/type/date/description/data | required strings | user's classification type, description, filename/date, base64 URI; UI/report metadata; bytes only backup/preview |
| Evidence.stage | optional string | recorded workflow stage; report/export |
| Job.audit | required Audit[] | locally editable change history; not cryptographic proof |
| Audit.at/field/before/after | at,field strings; before/after unknown | import validates at/field strings; UI/report JSON history; may coalesce rapid same-field edits |
| Job.approvals | optional Approval[] | preserved design versions, rendered/report/export |
| Approval.id/at/data/evidence | string/date/stringmap/Evidence[] | timestamp parseable, data/evidence validated; design matching controls review |
| ReferenceRate.id/date/k24/k22/k18/source/notes/checkedAt/method | string fields; method Manual | date valid; k values positive0.01..1e9 INR/g; exact Goodreturns URL; checkedAt parseable; notes<20000; displayed/snapshot/export |

All structured Job fields are included in full backup. Report presentation varies by selected report type; complete report includes summaries, detailed fields, checklists, approvals/evidence metadata and history. Print does not include binary attachments. Requiredness below refers to review/calculation, not preventing draft save.

## Business data fields

Shared storage/export rule for every row: Job.data string, IndexedDB, full JSON backup. Comparison-only fields instead live in Store.comparison string maps. Entered/displayed location is shown per row; consumer fields are listed in complete report detail sections, legacy fields in Recorded details, comparison fields on cards (not each job report). Metadata appears only in relevant summary/exception/rate/history sections, not every report variant. Calculation column distinguishes numeric participation from review/routing use; presence in validator alone is not a financial calculation.

| Field | Purpose / label | Type / limits / choices | Requiredness | Entry/display/report location | Calculation or control use |
|---|---|---|---|---|---|
| acceptedFineness | Accepted fineness (0–1000) | string; finite numeric 0..1000 | Required for acceptedValue | consumer purity | Numeric calculation/reconciliation; see CALCULATIONS |
| acceptedRate | Jeweller accepted rate (₹/g) | string; finite numeric 0.01..1000000000 | Required actual valuation | consumer valuation | Numeric calculation/reconciliation; see CALCULATIONS |
| acceptedWeight | Accepted net metal weight (g) | string; finite numeric 1e-06..1000000 | Required for old-gold valuation | consumer weights | Numeric calculation/reconciliation; see CALCULATIONS |
| actualChain | Final chain weight (g, if applicable) | string; finite numeric 1e-06..1000000 | Required if entered/planned; legacy collection required | consumer collection, legacy collection | Numeric calculation/reconciliation; see CALCULATIONS |
| actualLeftover | Actual leftover returned (g) | string; finite numeric 0..1000000 | Required collection except flow2 Buy; zero allowed | consumer collection, legacy collection | Numeric calculation/reconciliation; see CALCULATIONS |
| actualRing | Final ring weight (g, if applicable) | string; finite numeric 1e-06..1000000 | Required if entered/planned; legacy collection required | consumer collection, legacy collection | Numeric calculation/reconciliation; see CALCULATIONS |
| approvalDate | Approval date | string; date input (consumer review checks listed date keys) | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| articleDescription | Article description | string | Conditional by mode/stage; otherwise optional draft field | consumer bill, legacy invoice | Record/display; not an automatic formula |
| articleHuid | Article HUID (six alphanumeric characters) | string | Required HUID stage unless huidNA | consumer huid | Review/routing/reference control |
| billDiscount | Final discount (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill, legacy invoice | Numeric calculation/reconciliation; see CALCULATIONS |
| billFinal | Final amount on invoice (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | legacy invoice | Review/routing/reference control |
| billFineness | Invoice fineness | string; finite numeric 0..1000 | Required nonsale invoice | consumer bill, legacy invoice | Record/display; not an automatic formula |
| billFormat | Separate stones versus legacy combined other charges | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| billGST | Final GST (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill, legacy invoice | Numeric calculation/reconciliation; see CALCULATIONS |
| billGross | Invoice gross jewellery weight (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill | Record/display; not an automatic formula |
| billHallmark | Final hallmarking (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill, legacy invoice | Numeric calculation/reconciliation; see CALCULATIONS |
| billMaking | Final making (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill, legacy invoice | Numeric calculation/reconciliation; see CALCULATIONS |
| billNet | Invoice net precious-metal weight (g) | string; finite numeric 1e-06..1000000 | Required nonsale invoice | consumer bill, legacy invoice | Record/display; not an automatic formula |
| billOther | Final stones and other charges (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill, legacy invoice | Numeric calculation/reconciliation; see CALCULATIONS |
| billStones | Separate final stone charge INR | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Numeric calculation/reconciliation; see CALCULATIONS |
| billWastage | Final wastage (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill, legacy invoice | Numeric calculation/reconciliation; see CALCULATIONS |
| bisChecked | BIS mark checked | string; Not recorded, Yes, No | Must Yes unless huidNA | consumer huid | Review/routing/reference control |
| branch | Branch / location | string | Conditional by mode/stage; otherwise optional draft field | consumer parties, legacy basics | Record/display; not an automatic formula |
| buybackPolicy | Buyback policy | string | Conditional by mode/stage; otherwise optional draft field | comparison card, consumer buyback | Record/display; not an automatic formula |
| chain | Chain design | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| chainBis | Manually recorded chain BIS mark check | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| chainColour | Gold colour | string; Yellow, White, Rose, Other | Conditional by mode/stage; otherwise optional draft field | legacy chain design | Record/display; not an automatic formula |
| chainHuid | HUID | string | Conditional by mode/stage; otherwise optional draft field | legacy chain hallmark | Record/display; not an automatic formula |
| chainLength | Length (inches) | string | Conditional by mode/stage; otherwise optional draft field | legacy chain design | Record/display; not an automatic formula |
| chainNotes | Design notes | string | Conditional by mode/stage; otherwise optional draft field | legacy chain design | Record/display; not an automatic formula |
| chainPurityMark | Purity mark | string | Conditional by mode/stage; otherwise optional draft field | legacy chain hallmark | Record/display; not an automatic formula |
| chainStyle | Design style | string; Clean / Simple / Minimal, Classic, Custom | Conditional by mode/stage; otherwise optional draft field | legacy chain design | Record/display; not an automatic formula |
| chainVerifyDate | Verification date | string; date input (consumer review checks listed date keys) | Conditional by mode/stage; otherwise optional draft field | legacy chain hallmark | Record/display; not an automatic formula |
| chainVerifyNotes | Official result / verification notes | string | Conditional by mode/stage; otherwise optional draft field | legacy chain hallmark | Record/display; not an automatic formula |
| chainVerifyStatus | Manual verification result | string; Not verified, Matches official result, Difference found, Unable to verify | Conditional by mode/stage; otherwise optional draft field | legacy chain hallmark | Record/display; not an automatic formula |
| chainWeight | Target gross weight (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | legacy chain design | Numeric calculation/reconciliation; see CALCULATIONS |
| chainWidth | Width / profile | string | Conditional by mode/stage; otherwise optional draft field | legacy chain design | Record/display; not an automatic formula |
| collectionConditions | Collection conditions | string | Conditional by mode/stage; otherwise optional draft field | consumer handover | Record/display; not an automatic formula |
| collectionDate | Agreed collection date | string; date input (consumer review checks listed date keys) | Required handover/manufacturing unless N/A | consumer handover, consumer manufacturing, legacy manufacture | Record/display; not an automatic formula |
| collectionWeight | Weight observed at collection (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer collection | Record/display; not an automatic formula |
| colour | Colour | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| completedWithExceptionsAt | ISO timestamp of exception completion | string | Conditional by mode/stage; otherwise optional draft field | workflow/report metadata | Review/routing/reference control |
| completionIssues | JSON array of outstanding stage/message objects | string | Conditional by mode/stage; otherwise optional draft field | workflow/report metadata | Review/routing/reference control |
| completionReason | Nonblank reason for exception completion | string | Required exception path | workflow/report metadata | Review/routing/reference control |
| componentWeight | Recorded non-gold components (g) | string; finite numeric 0..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer weights | Record/display; not an automatic formula |
| conditionRequirements | Condition requirements | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| consumerChecklistVersion | Versioned checklist requirements | string | Conditional by mode/stage; otherwise optional draft field | workflow/report metadata | Review/routing/reference control |
| consumerFlowVersion | Versioned routing contract | string | Conditional by mode/stage; otherwise optional draft field | workflow/report metadata | Review/routing/reference control |
| consumerMode | One of five supported transaction modes | string | Conditional by mode/stage; otherwise optional draft field | workflow/report metadata | Review/routing/reference control |
| creditAdjustment | Additional credit adjustment (₹) | string; finite numeric 0..1000000000 | Required exchange/sale credit, explicit zero allowed | consumer valuation | Numeric calculation/reconciliation; see CALCULATIONS |
| customDesign | Whether new purchase requires preserved design approval | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| customer | Customer name | string | Optional; checklist asks recording | consumer parties, legacy basics | Record/display; not an automatic formula |
| customerAcknowledgement | Customer acknowledgement | string | Conditional by mode/stage; otherwise optional draft field | consumer bill | Record/display; not an automatic formula |
| date | Transaction date | string; date input (consumer review checks listed date keys) | Required consumer stage 0 | consumer parties, legacy basics | Record/display; not an automatic formula |
| deductionNotes | Itemised deductions and basis — components, testing, melting/refining, exchange and other | string | Conditional by mode/stage; otherwise optional draft field | consumer valuation | Record/display; not an automatic formula |
| deductions | Total deductions including testing (₹) | string; finite numeric 0..1000000000 | Required exchange/sale credit, explicit zero allowed | consumer valuation | Numeric calculation/reconciliation; see CALCULATIONS |
| delivery | Delivery terms | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| designNotes | Design / valuation specification | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| designNumber | Design reference / number | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| dimensions | Dimensions | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| discount | Discount (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | comparison card, consumer tax, rate/quotation/bill or legacy form | Numeric calculation/reconciliation; see CALCULATIONS |
| distinctiveMarks | Distinctive marks / article details | string | Conditional by mode/stage; otherwise optional draft field | consumer weights | Record/display; not an automatic formula |
| engraving | Engraving | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| evidence | Evidence references | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| exchange | Exchange credit (₹, optional) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Numeric calculation/reconciliation; see CALCULATIONS |
| exchangeConditions | Exchange conditions | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| exchangePolicy | Exchange policy | string | Conditional by mode/stage; otherwise optional draft field | comparison card, consumer buyback | Record/display; not an automatic formula |
| finalBalance | Final balance payable (₹; negative = credit) | string; finite numeric -1000000000000..1000000000000 | Required nonsale balance reconciliation | consumer bill | Review/routing/reference control |
| finalCredit | Final exchange credit (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill | Numeric calculation/reconciliation; see CALCULATIONS |
| finalDelivery | Actual delivery date | string; date input (consumer review checks listed date keys) | Conditional by mode/stage; otherwise optional draft field | consumer bill | Record/display; not an automatic formula |
| finalDesign | Final design | string | Conditional by mode/stage; otherwise optional draft field | consumer bill | Record/display; not an automatic formula |
| finalGold | Final gold value (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill | Numeric calculation/reconciliation; see CALCULATIONS |
| finalGross | Final jewellery gross weight (g) | string; finite numeric 1e-06..1000000 | Required consumer collection | consumer collection | Numeric calculation/reconciliation; see CALCULATIONS |
| finalPurity | Final purity | string | Conditional by mode/stage; otherwise optional draft field | consumer bill | Record/display; not an automatic formula |
| finalRate | Final rate (₹/g) | string; finite numeric 0.01..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer bill | Record/display; not an automatic formula |
| fineness | Tested fineness (0–1000) | string; finite numeric 0..1000 | Required legacy purity | legacy purity | Numeric calculation/reconciliation; see CALCULATIONS |
| finish | Finish | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| futureBuybackRate | Gold-rate basis for future buyback | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| futureDeductions | Applicable future deductions | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| goldRate | Legacy reference gold rate INR/g | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| goldValue | Gold value (₹, optional) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Numeric calculation/reconciliation; see CALCULATIONS |
| gst | GST (₹) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Numeric calculation/reconciliation; see CALCULATIONS |
| hallmark | Hallmarking (₹) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Numeric calculation/reconciliation; see CALCULATIONS |
| hallmarkTreatment | Hallmarking-charge treatment | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| handoverDate | Date handed over | string; date input (consumer review checks listed date keys) | Required handover unless N/A | consumer handover, legacy manufacture | Record/display; not an automatic formula |
| handoverNA | If no handover: explain why | string | Conditional by mode/stage; otherwise optional draft field | consumer handover | Review/routing/reference control |
| handoverReason | Reason for handover | string; Exchange, Remaking, Repair, Melting, Valuation, Other | Required handover unless N/A | consumer parties | Record/display; not an automatic formula |
| handoverTime | Handover time / time zone | string | Conditional by mode/stage; otherwise optional draft field | consumer handover | Record/display; not an automatic formula |
| holdingPeriod | Minimum holding period, if any | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| huid | HUID process | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| huidNA | If not applicable: record reason | string | Conditional by mode/stage; otherwise optional draft field | consumer huid | Review/routing/reference control |
| importedRecordId | Original display ID retained on import | string | Conditional by mode/stage; otherwise optional draft field | workflow/report metadata | Review/routing/reference control |
| invoiceDate | Invoice / receipt date | string; date input (consumer review checks listed date keys) | Required final bill/receipt | consumer bill, legacy invoice | Record/display; not an automatic formula |
| invoiceNumber | Invoice / sale receipt number | string | Required final bill/receipt | consumer bill, legacy invoice | Record/display; not an automatic formula |
| jeweller | Jeweller name | string | Required stage 0 | comparison card, consumer parties, legacy basics | Record/display; not an automatic formula |
| jewellerRate | Jeweller quoted rate INR/g | string; finite numeric 0.01..1000000000 | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| jobNumber | Work order / job number | string | Required handover unless N/A; legacy manufacturing | consumer parties, legacy basics, legacy manufacture | Record/display; not an automatic formula |
| karat | Karat (optional) | string; finite numeric 1e-06..24 | Conditional by mode/stage; otherwise optional draft field | legacy purity | Record/display; not an automatic formula |
| leftover | Leftover gold policy | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| leftoverExplanation | Weight / leftover difference explanation | string | Conditional by mode/stage; otherwise optional draft field | legacy collection | Record/display; not an automatic formula |
| leftoverPolicy | Leftover gold agreement | string | Conditional by mode/stage; otherwise optional draft field | consumer handover, legacy manufacture | Record/display; not an automatic formula |
| making | Making charge (₹) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Numeric calculation/reconciliation; see CALCULATIONS |
| makingRefund | Making-charge refund terms | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| manufacturingNA | If no manufacture/delivery: explain why | string | Conditional by mode/stage; otherwise optional draft field | consumer manufacturing | Review/routing/reference control |
| method | Manufacturing method / meaning of 5D | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| missing | Missing information | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| newGross | Expected new gross weight (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer design | Review/routing/reference control |
| newNet | New jewellery net metal weight (g) | string; finite numeric 1e-06..1000000 | Required buy/exchange gold cost | consumer design | Numeric calculation/reconciliation; see CALCULATIONS |
| newPurity | New jewellery purity / fineness | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| notes | Notes | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| oldRateBasis | Accepted rate basis | string; At accepted purity, Fine gold (1000) | Conditional by mode/stage; otherwise optional draft field | consumer valuation | Review/routing/reference control |
| oldRatePurity | Reference purity for valuation | string; 24K, 22K, 18K, Custom | Conditional by mode/stage; otherwise optional draft field | consumer valuation | Review/routing/reference control |
| originalInvoice | Original invoice requirement | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| other | Other charges including stones (₹) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Numeric calculation/reconciliation; see CALCULATIONS |
| otherTreatment | Other-charge treatment | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| paid | Total paid / received (₹) | string; finite numeric 0..1000000000 | Required final bill/receipt | consumer bill, legacy invoice | Review/routing/reference control |
| paymentMethod | Payment method | string | Required checklist version1 bill | consumer bill | Record/display; not an automatic formula |
| paymentReference | Receipt / payment reference | string | Required checklist version1 bill | consumer bill | Record/display; not an automatic formula |
| phone | Jeweller contact | string | Conditional by mode/stage; otherwise optional draft field | consumer parties, legacy basics | Record/display; not an automatic formula |
| policyReference | Written policy / document reference | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| productionUpdate | Manufacturing / delivery update | string | Conditional by mode/stage; otherwise optional draft field | consumer manufacturing, legacy manufacture | Record/display; not an automatic formula |
| purity | Purity / fineness | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| purityMark | Purity / fineness mark | string | Required HUID stage unless huidNA | consumer huid | Record/display; not an automatic formula |
| purposeNotes | Purpose / promised outcome | string | Conditional by mode/stage; otherwise optional draft field | consumer parties | Record/display; not an automatic formula |
| rate | Gold rate (₹/g) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| rateNotes | Rate basis/source/custom purity notes | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| ratePurity | Selected 24K/22K/18K/Custom rate basis | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| rateQuotedAt | Date/time/time zone of quoted rate | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| rateSnapshot | JSON-encoded immutable reference-rate snapshot | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| rateUsed | Explicit transaction calculation rate INR/g | string; finite numeric 0.01..1000000000 | Required buy/exchange gold cost | rate/quotation/bill or legacy form | Numeric calculation/reconciliation; see CALCULATIONS |
| receipt | Job-work receipt | string; Not recorded, Available, Not available | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| receivedWeight | Jeweller received gross weight (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer weights | Record/display; not an automatic formula |
| reconcileNotes | Explanation of weight / design / delivery differences | string | Conditional by mode/stage; otherwise optional draft field | consumer collection | Review/routing/reference control |
| recordId | Customer-visible record identifier | string | Conditional by mode/stage; otherwise optional draft field | workflow/report metadata | Review/routing/reference control |
| repairConditions | Repair / resizing conditions | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| returnConditions | Return / cancellation conditions | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| ring | Ring design | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| ringBis | Manually recorded ring BIS mark check | string | Conditional by mode/stage; otherwise optional draft field | rate/quotation/bill or legacy form | Review/routing/reference control |
| ringColour | Gold colour | string; Yellow, White, Rose, Other | Conditional by mode/stage; otherwise optional draft field | legacy ring design | Record/display; not an automatic formula |
| ringHuid | HUID | string | Conditional by mode/stage; otherwise optional draft field | legacy ring hallmark | Record/display; not an automatic formula |
| ringNotes | Design notes | string | Conditional by mode/stage; otherwise optional draft field | legacy ring design | Record/display; not an automatic formula |
| ringPurityMark | Purity mark | string | Conditional by mode/stage; otherwise optional draft field | legacy ring hallmark | Record/display; not an automatic formula |
| ringSize | Ring size (optional) | string | Conditional by mode/stage; otherwise optional draft field | legacy ring design | Record/display; not an automatic formula |
| ringStone | Stone preference | string | Conditional by mode/stage; otherwise optional draft field | legacy ring design | Record/display; not an automatic formula |
| ringStyle | Design style | string; Minimal, Classic, Modern, Dhanusu / Sagittarius, Custom | Conditional by mode/stage; otherwise optional draft field | legacy ring design | Record/display; not an automatic formula |
| ringVerifyDate | Verification date | string; date input (consumer review checks listed date keys) | Conditional by mode/stage; otherwise optional draft field | legacy ring hallmark | Record/display; not an automatic formula |
| ringVerifyNotes | Official result / verification notes | string | Conditional by mode/stage; otherwise optional draft field | legacy ring hallmark | Record/display; not an automatic formula |
| ringVerifyStatus | Manual verification result | string; Not verified, Matches official result, Difference found, Unable to verify | Conditional by mode/stage; otherwise optional draft field | legacy ring hallmark | Record/display; not an automatic formula |
| ringWeight | Target gross weight (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | legacy ring design | Numeric calculation/reconciliation; see CALCULATIONS |
| starting | Starting gold weight (g) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| stoneDetails | Stone details | string | Conditional by mode/stage; otherwise optional draft field | consumer design | Record/display; not an automatic formula |
| stoneTreatment | Stone-charge treatment | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| stoneWeight | Stone weight (g, if applicable) | string; finite numeric 0..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer weights | Record/display; not an automatic formula |
| taxAmount | GST manual amount (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer tax, rate/quotation/bill or legacy form | Numeric calculation/reconciliation; see CALCULATIONS |
| taxBase | GST taxable base (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer tax, rate/quotation/bill or legacy form | Numeric calculation/reconciliation; see CALCULATIONS |
| taxMode | GST entry method | string; Manual amount, Percentage of entered base | Conditional by mode/stage; otherwise optional draft field | consumer tax, rate/quotation/bill or legacy form | Review/routing/reference control |
| taxNotes | GST treatment / quotation notes | string | Conditional by mode/stage; otherwise optional draft field | consumer tax, rate/quotation/bill or legacy form | Review/routing/reference control |
| taxRate | GST rate (%) | string; finite numeric 0..100 | Conditional by mode/stage; otherwise optional draft field | consumer tax, rate/quotation/bill or legacy form | Numeric calculation/reconciliation; see CALCULATIONS |
| testDate | Testing date | string; date input (consumer review checks listed date keys) | Conditional by mode/stage; otherwise optional draft field | consumer purity, legacy purity | Record/display; not an automatic formula |
| testMethod | Testing method | string | Conditional by mode/stage; otherwise optional draft field | consumer purity, legacy purity | Record/display; not an automatic formula |
| testNotes | Testing notes | string | Conditional by mode/stage; otherwise optional draft field | legacy purity | Record/display; not an automatic formula |
| testResult | Testing result / scope | string | Conditional by mode/stage; otherwise optional draft field | consumer purity, legacy purity | Record/display; not an automatic formula |
| testedWeight | Tested weight (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer weights | Record/display; not an automatic formula |
| testingRequirements | Purity testing requirements | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| verifiedBy | Verified by | string | Required legacy weight stage | legacy weight | Record/display; not an automatic formula |
| verifiedWeight | Verified starting weight (g) | string; finite numeric 1e-06..1000000 | Required legacy weight stage | legacy weight | Review/routing/reference control |
| verifyDate | Verification date | string; date input (consumer review checks listed date keys) | Required HUID stage unless huidNA | consumer huid | Record/display; not an automatic formula |
| verifyNotes | Verification details / additional article HUIDs | string | Conditional by mode/stage; otherwise optional draft field | consumer huid | Record/display; not an automatic formula |
| verifyStatus | Official manual verification result | string; Not verified, Matches official result, Difference found, Unable to verify | Must Matches official result unless huidNA | consumer huid | Review/routing/reference control |
| warranty | Warranty / return terms | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| wastage | Wastage amount (₹) | string; numeric input; no additional field-specific bound registered | Conditional by mode/stage; otherwise optional draft field | comparison card | Numeric calculation/reconciliation; see CALCULATIONS |
| wastageRefund | Wastage refund terms | string | Conditional by mode/stage; otherwise optional draft field | consumer buyback | Record/display; not an automatic formula |
| wasteAmount | Fixed/custom wastage amount (₹) | string; finite numeric 0..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer wastage, legacy waste | Numeric calculation/reconciliation; see CALCULATIONS |
| wasteBasis | Wastage calculation basis | string; Percentage, Grams, Rupees, Custom | Conditional by mode/stage; otherwise optional draft field | consumer wastage, legacy waste | Review/routing/reference control |
| wasteExplanation | Wastage explanation / custom calculation | string | Conditional by mode/stage; otherwise optional draft field | consumer wastage, legacy waste | Review/routing/reference control |
| wasteGrams | Quoted wastage grams | string; finite numeric 0..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer wastage, legacy waste | Numeric calculation/reconciliation; see CALCULATIONS |
| wastePercent | Wastage percentage (%) | string; finite numeric 0..100 | Conditional by mode/stage; otherwise optional draft field | consumer wastage, legacy waste | Numeric calculation/reconciliation; see CALCULATIONS |
| wasteRate | Wastage rate (₹/g) | string; finite numeric 0.01..1000000000 | Conditional by mode/stage; otherwise optional draft field | consumer wastage | Numeric calculation/reconciliation; see CALCULATIONS |
| wasteTerms | Wastage explanation | string | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |
| wasteWeight | Applicable wastage weight (g) | string; finite numeric 1e-06..1000000 | Conditional by mode/stage; otherwise optional draft field | consumer wastage | Numeric calculation/reconciliation; see CALCULATIONS |
| weighNotes | Weighing method / evidence / explanation | string | Conditional by mode/stage; otherwise optional draft field | consumer weights | Record/display; not an automatic formula |
| weightTime | Weighing date & time | string | Required legacy weight stage | legacy weight | Record/display; not an automatic formula |
| written | Written quotation | string; Not recorded, Obtained, Not obtained | Conditional by mode/stage; otherwise optional draft field | comparison card | Record/display; not an automatic formula |

## Dynamic fields and bounds not represented by static form definitions

- `data.checklistNA-<index>`: optional string explanation for a transaction checklist item; a nonblank reason resolves that pending item without setting the checkbox. Reported in checklist summary and exported.
- Suggested-question answer keys and risk/question reason fields are dynamic strings set by the consumer components; saved in Job.data, displayed in question panels and detailed report, exported. See the exact source key references below; no invented fixed schema is imposed on these maps.
- `data.rateSnapshot` and `data.completionIssues` contain JSON encoded inside a string, not nested database columns. The latter records {stage,message} objects at exception completion. They remain raw data in backup.
- Transaction mode display 'Hand over for job work' is stored as `Hand over old gold`. Preserve stored enum values on restoration.
- `billFormat='Separate stones'` means billOther excludes billStones. Legacy records with no marker retain combined stones/other behavior.
- Gross weight, accepted net weight, test weight, observed collection weight and final gross are distinct observations. Stone/components are not automatically subtracted from gross to invent a tested net weight.
- Evidence date/classification are user-supplied metadata, not file-authentication signals. HUID format alone is not verification.

## Complete registered numeric bounds

- `acceptedFineness`: 0 to 1000, inclusive when nonblank.
- `acceptedRate`: 0.01 to 1000000000, inclusive when nonblank.
- `acceptedWeight`: 1e-06 to 1000000, inclusive when nonblank.
- `actualChain`: 1e-06 to 1000000, inclusive when nonblank.
- `actualLeftover`: 0 to 1000000, inclusive when nonblank.
- `actualRing`: 1e-06 to 1000000, inclusive when nonblank.
- `billDiscount`: 0 to 1000000000, inclusive when nonblank.
- `billFinal`: 0 to 1000000000, inclusive when nonblank.
- `billFineness`: 0 to 1000, inclusive when nonblank.
- `billGST`: 0 to 1000000000, inclusive when nonblank.
- `billGross`: 1e-06 to 1000000, inclusive when nonblank.
- `billHallmark`: 0 to 1000000000, inclusive when nonblank.
- `billMaking`: 0 to 1000000000, inclusive when nonblank.
- `billNet`: 1e-06 to 1000000, inclusive when nonblank.
- `billOther`: 0 to 1000000000, inclusive when nonblank.
- `billStones`: 0 to 1000000000, inclusive when nonblank.
- `billWastage`: 0 to 1000000000, inclusive when nonblank.
- `chainWeight`: 1e-06 to 1000000, inclusive when nonblank.
- `collectionWeight`: 1e-06 to 1000000, inclusive when nonblank.
- `componentWeight`: 0 to 1000000, inclusive when nonblank.
- `creditAdjustment`: 0 to 1000000000, inclusive when nonblank.
- `deductions`: 0 to 1000000000, inclusive when nonblank.
- `discount`: 0 to 1000000000, inclusive when nonblank.
- `finalBalance`: -1000000000000 to 1000000000000, inclusive when nonblank.
- `finalCredit`: 0 to 1000000000, inclusive when nonblank.
- `finalGold`: 0 to 1000000000, inclusive when nonblank.
- `finalGross`: 1e-06 to 1000000, inclusive when nonblank.
- `finalRate`: 0.01 to 1000000000, inclusive when nonblank.
- `fineness`: 0 to 1000, inclusive when nonblank.
- `goldRate`: 0 to 1000000000, inclusive when nonblank.
- `jewellerRate`: 0.01 to 1000000000, inclusive when nonblank.
- `k18`: 0.01 to 1000000000, inclusive when nonblank.
- `k22`: 0.01 to 1000000000, inclusive when nonblank.
- `k24`: 0.01 to 1000000000, inclusive when nonblank.
- `karat`: 1e-06 to 24, inclusive when nonblank.
- `newGross`: 1e-06 to 1000000, inclusive when nonblank.
- `newNet`: 1e-06 to 1000000, inclusive when nonblank.
- `paid`: 0 to 1000000000, inclusive when nonblank.
- `rateUsed`: 0.01 to 1000000000, inclusive when nonblank.
- `receivedWeight`: 1e-06 to 1000000, inclusive when nonblank.
- `ringWeight`: 1e-06 to 1000000, inclusive when nonblank.
- `stoneWeight`: 0 to 1000000, inclusive when nonblank.
- `taxAmount`: 0 to 1000000000, inclusive when nonblank.
- `taxBase`: 0 to 1000000000, inclusive when nonblank.
- `taxRate`: 0 to 100, inclusive when nonblank.
- `testedWeight`: 1e-06 to 1000000, inclusive when nonblank.
- `verifiedWeight`: 1e-06 to 1000000, inclusive when nonblank.
- `wasteAmount`: 0 to 1000000000, inclusive when nonblank.
- `wasteGrams`: 0 to 1000000, inclusive when nonblank.
- `wastePercent`: 0 to 100, inclusive when nonblank.
- `wasteRate`: 0.01 to 1000000000, inclusive when nonblank.
- `wasteWeight`: 1e-06 to 1000000, inclusive when nonblank.

## Additional exact dynamic/comparison keys

- `data.suggestedAnswer-<question id>`: saved answer to a suggested question; string, optional, no numeric calculation; entered in journey question panel, listed under saved answers in complete report and exported.
- `Store.comparison[].comparisonFormat`: string marker `Separate stones` for new cards; selects separate stone addition. Optional on legacy cards; backup preserves it.
- `Store.comparison[].stones`: numeric-input string, explicit nonnegative amount required for total when separate-stones format; moneyValue rounds to two decimals; displayed on comparison card/print and exported.
