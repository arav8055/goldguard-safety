# Deployment and recovery deployment

Current host: OpenAI ChatGPT Sites, backed by a Cloudflare Worker and client assets.
Production: https://goldguard-jewellery-safety.danush-s366107.chatgpt.site
Project: appgprj_6aba19d4860c8191a192a56875d52c91
Saved version: 8 / appgprj_6aba19d4860c8191a192a56875d52c91~appgver_1ce8509de1d081918057020c3a63229f
Deployment: appgdep_6ac6532e4dbc8191ba9200bce92c361a
Commit: 1665371bc3c035e046f0453806e316e9c2df8df5
Audience: custom/private, one owner and one external viewer. No viewer contact data or auth credentials are included. D1/R2 are null. No hosted transaction database is provisioned by this app configuration.

## Build and local production preview

Install Node/pnpm versions in DEPENDENCIES.md, unzip and cd source. Run frozen dependency installation, all tests, build, then TypeScript command as documented there. `pnpm run start` serves dist/server/wrangler.json locally through Wrangler. It is a local Worker emulator, not the hosted production deployment. Verify root/dashboard, create only synthetic records in a separate profile, test reports and refresh before publishing a recovery site.

The build emits dist/client and dist/server with generated wrangler.json: main index.js, assets ../client, ESModule rules, no_bundle true, nodejs_compat, compatibility date 2026-05-15 in the current artifact. No D1, R2, KV or application vars are configured. Do not copy local tool state, credentials or .git into deployment assets.

## Existing Sites workflow (requires authorized account/tools)

The existing provider saved a site version associated with this source and uploaded the built artifact, then deployed that version with its private audience. Current source and deployment identity are archived; deployment control-plane access, auth tokens and provider infrastructure are not. In a recovered Sites project, use the provider's current source/version upload and private deployment workflow, configure audience before exposure, then inspect deployment status and live URL. The old project ID is provenance, not reusable ownership credentials. Do not assume it can resurrect a deleted project.

## Replacement platform

The closest target is Cloudflare Workers with the existing Vinext output. Create your own account/project and private access gate. Authenticate separately. From a tested recovery checkout, inspect generated dist/server/wrangler.json and configure the new worker name/account and access controls for the replacement environment. Wrangler supports deployment with `pnpm exec wrangler deploy --config dist/server/wrangler.json --name <replacement-worker-name>`; this is a documented recovery command only and **was not executed or validated against a new account**. Verify current account policy/provider requirements before running it. Do not use the development mock auth as production protection. Other hosts may require a Vinext-compatible adapter/configuration; a static-only host or plain next start is not established as compatible.

Recreate the custom domain with the replacement provider and use its newly supplied DNS/verification values. Do not reuse the current Sites A/TXT records at a different host. Import data through the app at the new origin. Browser records do not follow account sign-in or DNS changes automatically.

## Production verification and rollback

Check HTTPS/certificate, intended private audience, dashboard, a synthetic record, rounding, blocked mismatch, exception preservation, NEEDS CLARIFICATION report, evidence-copy wording, report rendering and refresh persistence. Export before/after any recovery data import; verify counts and exception metadata. Re-run tests and inspect app-origin console errors. Full mobile/print/security checks remain separate from these model tests.

Retain a known-good source archive, exact lockfile, independently verified data backups and optionally a separately retained built release. Roll back using provider version controls if available; otherwise rebuild this snapshot into an authorized replacement. Code rollback does not restore browser data. Never clear old-origin browser storage until an independent backup and successful restore have been confirmed. This archival task performed no deployment or rollback.
