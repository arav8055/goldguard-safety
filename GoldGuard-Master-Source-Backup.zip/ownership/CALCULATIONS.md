# Calculation specification — current source only

Authority: source/lib/goldguard/model.ts and journey.ts, plus display calculations in source/app/page.tsx and components/goldguard-consumer.tsx. All weights are grams; prices/charges are INR and rates INR/g. Empty/invalid inputs generally return null, rendered 'Not recorded', rather than zero. Explicit Included/Not applicable charges are zero.

## Parsing and precision

numeric accepts a nonblank string or number that converts to a finite Number within inclusive bounds. Default bounds are 0..1e9; field-specific limits are listed in DATA-DICTIONARY.md. Fraction conversion uses decimal representation of a JS Number, including exponent notation, then BigInt rational arithmetic. round(n,p=6) and multiply(a,b,divisor=1,p=2) round half-up in magnitude (negative half values away from zero). Addition before round still uses JS Number; this is not arbitrary-precision storage. Weights generally sum at 6 decimals; fine-gold products at 9; money rounds per line at 2. money formats INR using en-IN; grams normally displays at least 3 and up to 6 decimals, or up to 9 when requested with p=6. Thus 0.2 is displayed '0.200 g'.

| Calculation | Inputs and exact implemented behavior | Output |
|---|---|---|
| starting | Sum every pieces[].weight, each >0 and <=1e6; round sum to 6. Any missing/invalid piece -> null | gross g |
| fine (legacy) | starting × data.fineness /1000, fineness 0..1000; multiply to 9 decimals | fine g |
| pieceFine | pieces[].net (>0..1e6) × piece fineness (0..1000) /1000 at 9 decimals | fine g |
| fineTotal | sum all pieceFine results at 9 decimals; missing piece -> null | fine g |
| planned (legacy) | positive chainWeight + positive ringWeight, round6 | target gross g |
| goldValue | positive weight <=1e6 × rate 0.01..1e9, round2; product >1e12 -> null | INR |
| acceptedValue | At accepted purity: acceptedWeight × acceptedRate. Fine gold (1000): effective weight = acceptedWeight × acceptedFineness /1000 at 9 decimals, then × acceptedRate round2. Fineness is required even for accepted-purity basis | INR |
| reference acceptedValue | Uses saved reference rate and oldRatePurity. Fine gold basis only permits 24K and uses divisor **999**, not 1000, when reference=true. This is the source's reference comparison behavior, not a changed formula | indicative INR |
| exchangeCredit | acceptedValue − round(deductions,2) + round(creditAdjustment,2), round2; all inputs required | signed INR |
| charge fixed/custom | round(value,2); Custom basis requires nonblank notes | INR |
| charge percentage | explicit monetary base × value /100, round2; percentage 0..100 | INR |
| charge per gram | explicit gram base × value, round2 | INR |
| charge included/NA | exactly 0, without requiring base/value | INR |
| charge limit | base/value product or percentage result >1e12 -> null; Not specified/missing -> null | null or INR |
| quote subtotal | sum all 6 rounded charge lines, round2; any null -> null | INR |
| quote GST | manual moneyValue(taxAmount), or taxBase × taxRate /100, round2; rate 0..100, explicit base | INR |
| lineTotal | moneyValue each line and discount; sum rounded integer cents − rounded discount cents; negative -> null | INR |
| legacy quote | charges + GST − discount through lineTotal | additional INR |
| consumerQuote gold | Buy/Exchange: newNet × rateUsed; Remake/Sell/Hand over: 0 | INR |
| consumerQuote total | round(gold+charges+GST,2) − rounded discount, round2; discount exceeding gross -> null | INR |
| consumerQuote credit | Exchange/Sell use exchangeCredit; other modes 0 | INR |
| consumerQuote balance | Sell returns credit directly; other modes total − credit at 2 decimals; negative means credit to customer | signed INR |
| legacy bill | billMaking + billWastage + billHallmark + billOther + billGST − billDiscount, per-line round2; negative -> null | INR |
| consumerBill | finalGold + billMaking + billWastage + billHallmark + billOther + billGST + billStones only when billFormat='Separate stones', minus billDiscount and finalCredit; round2 | signed INR |
| wastageValue percentage | wasteWeight × wastePercent /100, round6, then × wasteRate round2 | g and INR |
| wastageValue grams | wasteGrams × wasteRate round2; grams may be 0 | g and INR |
| wastageValue rupees/custom | moneyValue(wasteAmount); custom requires wasteExplanation. Amount >1e12 -> null | INR |
| rateDifference | round(quoted−reference,2); round((quoted−reference)/reference×100,4) | INR/g and % |
| quote-final difference | legacy final invoice − quote total, round2. Consumer rows compare stored quoted/final values; not an automatic charge adjustment | INR or status |

Wastage calculator is a helper; verify the entered quotation charge line rather than assuming the helper automatically changes the final invoice. Karat labels are not silently converted to fineness. Gross/net/fine quantities are distinct. No automatic gold-rate feed or default legal GST rate is applied. Reference updates do not change recorded transaction snapshots or rateUsed.

Examples: 8+3=11.000 g; 7.982+3.014=10.996 g; 10.996×916/1000=10.072336 g. These are covered by model tests, not claims about physical assay accuracy.

## Reconciliation, payment and exceptions

collectionWeightProblem activates when either final chain/ring or planned chain/ring weight has been entered. Every applicable piece must have a positive valid final weight, and finalGross must be positive. Unused blank piece slots contribute zero. Sum = round(actualChain+actualRing,6); compare to round(finalGross,6). Difference = round(abs(sum−round(finalGross,6)),6). No legal tolerance is assumed. 7.2+3.0 versus 10.0 yields 'Collection weight mismatch: individual pieces total 10.200 g, but the recorded collection total is 10.000 g. Difference: 0.200 g.' The warning continues with correction/exception instructions. Matching weights yield no collection mismatch warning. This check does not subtract leftover from old gold or infer assay loss.

consumerProblems at Collection (7) and Completion (10) blocks ordinary review if collectionWeightProblem exists. A free-text explanation alone does not reconcile it. quoteFinalStatus forces the Gross weight row to NEEDS CLARIFICATION whenever that problem exists, even if newGross and finalGross match. Other rows return MISSING for missing inputs, MATCH for equal strings or numerically equal finite values, DIFFERENCE RECORDED when differing and reconcileNotes is present, otherwise NEEDS CLARIFICATION. Equality of non-weight rows is not certification.

Normal consumer final bill review requires consumerBill === numeric(finalBalance,-1e12,1e12). Sale review requires exchangeCredit === rounded paid. Payment method/reference are required for checklist version 1. Non-sale paid is recorded but consumerProblems does **not** enforce paid equals finalBalance; do not claim a universal payment-discrepancy blocker. Legacy invoice review compares calculated bill to rounded billFinal.

completeWithExceptions requires a nonblank reason, rejects invalid entered numeric/date values and net>gross pieces, then stores completionReason, JSON completionIssues and completedWithExceptionsAt plus an audit entry. It preserves discrepancy values and does not add false reviewed stages/checklist ticks. Missing information and mismatches can remain with an explicit reason. Reconciliation remains unresolved in the report.

Starting/verified, planned/actual and leftover displays are comparisons of entered quantities. Legacy allocation remainder = round(starting(job) − planned(job),6), using the sum of entered starting pieces (not verifiedWeight). Displayed expected remainder uses its absolute value with an additional-weight-needed label when negative. Leftover difference = round(actualLeftover − remainder,6). Per-article and total agreed-vs-actual differences = round(actual − planned,6). Consult exact display expressions in page.tsx; neither gross difference is converted into fine gold or a legally acceptable loss.

Three-jeweller comparison calls lineTotal on [goldValue or 0, making, wastage, hallmark, other, gst, stones only when comparisonFormat is Separate stones], subtracts discount inside lineTotal, then subtracts numeric(exchange or 0) and rounds to 2 decimals. A negative pre-credit lineTotal returns null, but the post-credit balance may be negative; it never fetches a live jeweller quote. Report totals call these same functions, rather than a separate PDF calculator. Preserve source and tests as executable specification where historical/legacy paths differ.
